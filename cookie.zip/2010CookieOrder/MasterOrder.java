/******************************************************************************
 *  Author:       Alwin Tareen
 *  Created:      Dec 13, 2018
 *  Last updated: Dec 13, 2018
 *
 *  Compilation:  javac MasterOrder.java
 *  Execution:    java MasterOrder
 *
 *  This program maintains a list of the cookies to be purchased.
 *
 ******************************************************************************/

import java.util.*;

public class MasterOrder
{
    // instance variables
    private ArrayList<CookieOrder> orders;
    
    // constructors
    public MasterOrder()
    {
        orders = new ArrayList<CookieOrder>();
    }
    
    // methods
    public void addOrder(CookieOrder theOrder)
    {
        orders.add(theOrder);
    }
    
    public int getTotalBoxes()
    {
        // YOUR CODE HERE
        
    }
    
    public int removeVariety(String cookieVar)
    {
        // YOUR CODE HERE
        
    }
    
    public ArrayList<CookieOrder> getOrders()
    {
        return orders;
    }
}