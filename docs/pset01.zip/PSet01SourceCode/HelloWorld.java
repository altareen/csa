/**
|-------------------------------------------------------------------------------
| HelloWorld
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: May 20, 2019
|
| This program displays a simple greeting to the user.
|
*/

public class HelloWorld
{
    public static String displayMessage()
    {
        // Use the assignment operator to assign the message "hello world"
        // to the String variable "greetings".
        // YOUR CODE HERE
        
        
        return greetings;
    }
    
    public static void main(String[] args)
    {
        String result = displayMessage();
        System.out.println(result);
    }
}
