/******************************************************************************
 *  Author:       YOUR NAME HERE
 *  Created:      Dec 05, 2018
 *  Last updated: Dec 05, 2018
 *
 *  Compilation:  javac Trail.java
 *  Execution:    java Trail
 *
 *  This program determines whether a trail is level or difficult.
 *
 ******************************************************************************/

public class Trail
{
    // instance variables
    private int[] markers;
    
    // constructors
    public Trail(int[] posts)
    {
        markers = posts;
    }
    
    public boolean isLevelTrailSegment(int start, int end)
    {
        // YOUR CODE HERE
        
    }
    
    public boolean isDifficult()
    {
        // YOUR CODE HERE
        
    }
}