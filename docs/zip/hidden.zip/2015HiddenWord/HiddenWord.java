/**
|-------------------------------------------------------------------------------
| HiddenWord.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 4, 2020
|
| This program implements a word guessing game.
|
*/

public class HiddenWord
{
    // YOUR CODE HERE
    
}