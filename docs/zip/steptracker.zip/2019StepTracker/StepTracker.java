/**
|-------------------------------------------------------------------------------
| StepTracker.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 11, 2020
|
| This program implements a fitness tracking system.
|
*/

public class StepTracker
{
    // YOUR CODE HERE
    
}