/**
|-------------------------------------------------------------------------------
| GeneDetection.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Oct 16, 2019
|
| This program determines which gene is present in a DNA sequence.
|
*/

public class GeneDetection
{
    public static String findGene(String dna, String stopCodon)
    {
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {        
        String result = findGene("ATATGTAGCTAGCATAATA", "TAA");
        System.out.println(result);
    }
}
