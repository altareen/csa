/**
|-------------------------------------------------------------------------------
| APLine.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Nov 14, 2019
|
| This program defines the equation of a straight line.
|
*/

public class APLine
{
    // YOUR CODE HERE
    
}