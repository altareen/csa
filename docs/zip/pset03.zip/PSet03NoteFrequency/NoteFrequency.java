/**
|-------------------------------------------------------------------------------
| NoteFrequency.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Sep 15, 2019
|
| This program determines the frequency(in Hz) for a particular octave and
| pitch class.
|
*/

public class NoteFrequency
{
    public static double temperedScale(int octave, int pitch)
    {
        // YOUR CODE HERE
        
        return frequency;
    }
    
    public static void main(String[] args)
    {
        double result = temperedScale(0, 0);
        System.out.println(result);
    }
}
