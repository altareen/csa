/**
|-------------------------------------------------------------------------------
| NoteFrequencyJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Sep 15, 2019
|
| This program is the JUnit test bench for NoteFrequency.java
| Do not alter the contents of this file.
|
*/

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class NoteFrequencyJUnitTest
{
    @Test
    public void evaluateOne()
    {
        double expected = 16.35;
        double actual = NoteFrequency.temperedScale(0, 0);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void evaluateTwo()
    {
        double expected = 16744.036;
        double actual = NoteFrequency.temperedScale(10, 0);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void evaluateThree()
    {
        double expected = 440.00;
        double actual = NoteFrequency.temperedScale(4, 9);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void evaluateFour()
    {
        double expected = 50175.415;
        double actual = NoteFrequency.temperedScale(11, 7);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void evaluateFive()
    {
        double expected = 116.54;
        double actual = NoteFrequency.temperedScale(2, 10);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void evaluateSix()
    {
        double expected = 830.609;
        double actual = NoteFrequency.temperedScale(5, 8);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void evaluateSeven()
    {
        double expected = 369.99;
        double actual = NoteFrequency.temperedScale(4, 6);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void evaluateEight()
    {
        double expected = 2217.46;
        double actual = NoteFrequency.temperedScale(7, 1);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void evaluateNine()
    {
        double expected = 9956.063;
        double actual = NoteFrequency.temperedScale(9, 3);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void evaluateTen()
    {
        double expected = 100350.83;
        double actual = NoteFrequency.temperedScale(12, 7);
        assertEquals(expected, actual, 0.1);
    }
}
