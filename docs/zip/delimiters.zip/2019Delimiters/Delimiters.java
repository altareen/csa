/**
|-------------------------------------------------------------------------------
| Delimiters.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 11, 2020
|
| This program checks for the presence of valid delimiters.
|
*/

import java.util.*;

public class Delimiters
{
    private String openDel;
    private String closeDel;
    
    public Delimiters(String open, String close)
    {
        openDel = open;
        closeDel = close;
    }
    
    public ArrayList<String> getDelimitersList(String[] tokens)
    {
        // Part (a): YOUR CODE HERE
        
    }
    
    public boolean isBalanced(ArrayList<String> delimiters)
    {
        // Part (b): YOUR CODE HERE
        
    }
}