import java.util.*;
public class Delimiters
{
    // instance variables
    private String openDel;
    private String closeDel;
    
    // constructors
    public Delimiters(String open, String close)
    {
        openDel = open;
        closeDel = close;
    }
    
    // question (a)
    public ArrayList<String> getDelimitersList(String[] tokens)
    {
        // YOUR CODE HERE
        
    }
    
    // question (b)
    public boolean isBalanced(ArrayList<String> delimiters)
    {
        // YOUR CODE HERE
        
    }
}
