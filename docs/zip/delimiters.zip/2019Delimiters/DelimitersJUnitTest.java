/**
|-------------------------------------------------------------------------------
| DelimitersJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 11, 2019
|
| This is the test bench for Delimiters.java
|
| Do not alter the contents of this file.
|
*/

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import java.util.*;

public class DelimitersJUnitTest
{
    private Delimiters tags;
    private ArrayList<String> labels;
    private String[] elements;
    
    @Before
    public void runBeforeEachTest()
    {
        labels = new ArrayList<String>();
    }

    
    @After
    public void runAfterEachTest()
    {
        tags = null;
        labels = null;
        elements = null;
    }
    
    @Test
    public void getDelimitersListTestOne()
    {
        tags = new Delimiters("(", ")");
        elements = new String[] {"(", "x + y", ")", " * 5"};
        String expected = "[(, )]";
        String actual = tags.getDelimitersList(elements).toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void getDelimitersListTestTwo()
    {
        tags = new Delimiters("<q>", "</q>");
        elements = new String[] {"<q>", "yy", "</q>", "zz", "</q>"};
        String expected = "[<q>, </q>, </q>]";
        String actual = tags.getDelimitersList(elements).toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void getDelimitersListTestThree()
    {
        tags = new Delimiters("<body>", "</body>");
        elements = new String[] {"<html>", "</h1>", "</body>", "<head>", "<p>", "<body>", "emph", "<body>"};
        String expected = "[</body>, <body>, <body>]";
        String actual = tags.getDelimitersList(elements).toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void getDelimitersListTestFour()
    {
        tags = new Delimiters("/begin", "/end");
        elements = new String[] {"strong", "/h5", "/begin", "/begin", "emph", "bold", "/end", "/begin", "rule"};
        String expected = "[/begin, /begin, /end, /begin]";
        String actual = tags.getDelimitersList(elements).toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void getDelimitersListTestFive()
    {
        tags = new Delimiters("<script>", "</script>");
        elements = new String[] {"note", "code", "<script>", "</script>", "hack", "</script>", "<script>", "<script>"};
        String expected = "[<script>, </script>, </script>, <script>, <script>]";
        String actual = tags.getDelimitersList(elements).toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void isBalancedTestSix()
    {
        tags = new Delimiters("<sup>", "</sup>");
        labels.add("<sup>");
        labels.add("<sup>");
        labels.add("</sup>");
        labels.add("<sup>");
        labels.add("</sup>");
        labels.add("</sup>");
        boolean actual = tags.isBalanced(labels);
        assertTrue(actual);
    }
    
    @Test
    public void isBalancedTestSeven()
    {
        tags = new Delimiters("<sup>", "</sup>");
        labels.add("<sup>");
        labels.add("</sup>");
        labels.add("</sup>");
        labels.add("<sup>");
        boolean actual = tags.isBalanced(labels);
        assertFalse(actual);
    }
    
    @Test
    public void isBalancedTestEight()
    {
        tags = new Delimiters("<sup>", "</sup>");
        labels.add("<sup>");
        labels.add("<sup>");
        labels.add("</sup>");
        boolean actual = tags.isBalanced(labels);
        assertFalse(actual);
    }
    
    @Test
    public void isBalancedTestNine()
    {
        tags = new Delimiters("<head>", "</head>");
        labels.add("<head>");
        labels.add("<head>");
        labels.add("<head>");
        labels.add("</head>");
        labels.add("<head>");
        labels.add("</head>");
        labels.add("</head>");
        labels.add("</head>");
        boolean actual = tags.isBalanced(labels);
        assertTrue(actual);
    }
    
    @Test
    public void isBalancedTestTen()
    {
        tags = new Delimiters("<script>", "</script>");
        labels.add("<script>");
        labels.add("</script>");
        labels.add("<script>");
        labels.add("</script>");
        labels.add("<script>");
        labels.add("</script>");
        labels.add("<script>");
        labels.add("<script>");
        labels.add("<script>");
        labels.add("<script>");
        labels.add("</script>");
        labels.add("</script>");
        labels.add("</script>");
        labels.add("</script>");
        boolean actual = tags.isBalanced(labels);
        assertTrue(actual);
    }
}