/**
|-------------------------------------------------------------------------------
| MovieCritic.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Sep 19, 2019
|
| This program determines a user's particular interest in a certain movie.
|
*/

public class MovieCritic
{
    public static String selectFilm(double price, double rating)
    {
        String outcome = "";
        // YOUR CODE HERE
        
        return outcome;
    }
    
    public static void main(String[] args)
    {
        String result = selectFilm(6.5, 3.5);
        System.out.println(result);
    }
}
