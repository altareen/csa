/**
|-------------------------------------------------------------------------------
| MovieCriticJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Sep 19, 2019
|
| This program is the JUnit test bench for MovieCritic.java
| Do not alter the contents of this file.
|
*/

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class MovieCriticJUnitTest
{
    @Test
    public void evaluateOne()
    {
        String expected = "moderately interested";
        String actual = MovieCritic.selectFilm(6.5, 3.5);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateTwo()
    {
        String expected = "barely interested";
        String actual = MovieCritic.selectFilm(15.5, 5.0);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateThree()
    {
        String expected = "very interested";
        String actual = MovieCritic.selectFilm(10.5, 4.5);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateFour()
    {
        String expected = "moderately interested";
        String actual = MovieCritic.selectFilm(7.5, 2.5);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateFive()
    {
        String expected = "barely interested";
        String actual = MovieCritic.selectFilm(2.5, 1.5);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateSix()
    {
        String expected = "completely uninterested";
        String actual = MovieCritic.selectFilm(25.5, 0.5);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateSeven()
    {
        String expected = "moderately interested";
        String actual = MovieCritic.selectFilm(5.0, 2.0);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateEight()
    {
        String expected = "moderately interested";
        String actual = MovieCritic.selectFilm(11.99, 4.0);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateNine()
    {
        String expected = "barely interested";
        String actual = MovieCritic.selectFilm(4.99, 1.9);
        assertEquals(expected, actual);
    }
    
    @Test
    public void evaluateTen()
    {
        String expected = "extremely interested";
        String actual = MovieCritic.selectFilm(4.99, 2.0);
        assertEquals(expected, actual);
    }
}
