/**
|-------------------------------------------------------------------------------
| WordPairList.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 11, 2020
|
| This program generates pairs of words from an array.
|
*/

import java.util.*;

public class WordPairList
{
    private ArrayList<WordPair> allPairs;
    
    public WordPairList(String[] words)
    {
        // Part (a): YOUR CODE HERE
        
    }
    
    public int numMatches()
    {
        // Part (b): YOUR CODE HERE
        
    }
    
    public ArrayList<WordPair> getAllPairs()
    {
        return allPairs;
    }
}