/**
|-------------------------------------------------------------------------------
| WordPairListTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 11, 2020
|
| This program is the test bench for WordPairList.java
|
| Do not alter the contents of this file.
|
*/

public class WordPairListTest
{
    public static void main(String[] args)
    {
        String[] wordNums = {"one", "two", "three"};
        WordPairList exampleOne = new WordPairList(wordNums);
        System.out.println(exampleOne.getAllPairs());
        
        String[] phrase = {"the", "more", "the", "merrier"};
        WordPairList exampleTwo = new WordPairList(phrase);
        System.out.println(exampleTwo.getAllPairs());
        
        String[] moreWords = {"the", "red", "fox", "the", "red"};
        WordPairList exampleThree = new WordPairList(moreWords);
        System.out.println(exampleThree.getAllPairs());
        
        String[] fourthWords = {"tea", "tea", "tea", "coffee"};
        WordPairList exampleFour = new WordPairList(fourthWords);
        System.out.println(exampleFour.getAllPairs());
        
        String[] fifthWords = {"kiwi", "kiwi", "kiwi", "orange", "orange"};
        WordPairList exampleFive = new WordPairList(fifthWords);
        System.out.println(exampleFive.getAllPairs());
        
        int result = exampleThree.numMatches();
        System.out.println(result);
    }
}