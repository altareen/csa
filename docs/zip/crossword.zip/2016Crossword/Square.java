/**
|-------------------------------------------------------------------------------
| Square.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 5, 2020
|
| This program implements the coloring scheme and numbering pattern on a
| crossword puzzle.
|
*/

public class Square
{
    private boolean isBlackCell;
    private int number;
    
    public Square(boolean isBlack, int num)
    {
        isBlackCell = isBlack;
        number = num;
    }
    
    public int getNumber()
    {
        return number;
    }
    
    public String toString()
    {
        String result = "";
        if (isBlackCell)
        {
            result = "B";
        }
        else
        {
            result = String.valueOf(number);
        }
        return result;
    }
}