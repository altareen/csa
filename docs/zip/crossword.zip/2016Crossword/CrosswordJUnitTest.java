/**
|-------------------------------------------------------------------------------
| CrosswordJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 5, 2020
|
| This program is the JUnit test bench for Crossword.java
|
| Do not alter the contents of this file.
|
*/

import java.util.*;
import junit.framework.JUnit4TestAdapter;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CrosswordJUnitTest
{
    private Crossword game;
    private boolean[][] cells;
    
    @Before
    public void runBeforeEachTest()
    {
        cells = new boolean[][] {
        {true, false, false, true, true, true, false, false, false},
        {false, false, false, false, true, false, false, false, false},
        {false, false, false, false, false, false, true, true, true},
        {false, false, true, false, false, false, true, false, false},
        {true, true, true, false, false, false, false, false, false},
        {false, false, false, false, true, false, false, false, false},
        {false, false, false, true, true, true, false, false, true}
        };
        game = new Crossword(cells);
    }
    
    @After
    public void runAfterEachTest()
    {
        cells = null;
        game = null;
    }
    
    @Test
    public void toBeLabeledTestOne()
    {
        boolean actual = game.toBeLabeled(2, 4, cells);
        assertTrue(actual);
    }
    
    @Test
    public void toBeLabeledTestTwo()
    {
        boolean actual = game.toBeLabeled(4, 6, cells);
        assertTrue(actual);
    }
    
    @Test
    public void toBeLabeledTestThree()
    {
        boolean actual = game.toBeLabeled(5, 5, cells);
        assertTrue(actual);
    }
    
    @Test
    public void toBeLabeledTestFour()
    {
        boolean actual = game.toBeLabeled(3, 6, cells);
        assertFalse(actual);
    }
    
    @Test
    public void toBeLabeledTestFive()
    {
        boolean actual = game.toBeLabeled(6, 7, cells);
        assertFalse(actual);
    }
    
    @Test
    public void CrosswordConstructorTestSix()
    {
        String expected =
        "B   1   2   B   B   B   3   4   5   \n" +
        "6   0   0   7   B   8   0   0   0   \n" +
        "9   0   0   0   10  0   B   B   B   \n" +
        "11  0   B   12  0   0   B   13  14  \n" +
        "B   B   B   15  0   0   16  0   0   \n" +
        "17  18  19  0   B   20  0   0   0   \n" +
        "21  0   0   B   B   B   22  0   B   \n";
        String actual = game.toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void CrosswordConstructorTestSeven()
    {
        cells = new boolean[][] {
        {false,false,false,false,true,false,false,false,false,true,false,false,false,true,true},
        {false,false,false,false,true,false,false,false,false,true,false,false,false,false,true},
        {false,false,false,false,false,false,false,false,false,false,false,false,false,false,false},
        {true,false,false,false,false,true,false,false,false,false,true,true,false,false,false},
        {true,true,true,false,false,false,true,false,false,false,false,false,false,false,false},
        {false,false,false,false,true,false,false,false,true,true,false,false,false,false,false},
        {false,false,false,false,false,false,false,true,false,false,false,false,true,true,true},
        {false,false,false,true,false,false,false,true,false,false,false,true,false,false,false},
        {true,true,true,false,false,false,false,true,false,false,false,false,false,false,false},
        {false,false,false,false,false,true,true,false,false,false,true,false,false,false,false},
        {false,false,false,false,false,false,false,false,true,false,false,false,true,true,true},
        {false,false,false,true,true,false,false,false,false,true,false,false,false,false,true},
        {false,false,false,false,false,false,false,false,false,false,false,false,false,false,false},
        {true,false,false,false,false,true,false,false,false,false,true,false,false,false,false},
        {true,true,false,false,false,true,false,false,false,false,true,false,false,false,false},
        };
        game = new Crossword(cells);
        
        String expected =
        "1   2   3   4   B   5   6   7   8   B   9   10  11  B   B   \n" +
        "12  0   0   0   B   13  0   0   0   B   14  0   0   15  B   \n" +
        "16  0   0   0   17  0   0   0   0   18  0   0   0   0   19  \n" +
        "B   20  0   0   0   B   21  0   0   0   B   B   22  0   0   \n" +
        "B   B   B   23  0   24  B   25  0   0   26  27  0   0   0   \n" +
        "28  29  30  0   B   31  32  0   B   B   33  0   0   0   0   \n" +
        "34  0   0   0   35  0   0   B   36  37  0   0   B   B   B   \n" +
        "38  0   0   B   39  0   0   B   40  0   0   B   41  42  43  \n" +
        "B   B   B   44  0   0   0   B   45  0   0   46  0   0   0   \n" +
        "47  48  49  0   0   B   B   50  0   0   B   51  0   0   0   \n" +
        "52  0   0   0   0   53  54  0   B   55  56  0   B   B   B   \n" +
        "57  0   0   B   B   58  0   0   59  B   60  0   61  62  B   \n" +
        "63  0   0   64  65  0   0   0   0   66  0   0   0   0   67  \n" +
        "B   68  0   0   0   B   69  0   0   0   B   70  0   0   0   \n" +
        "B   B   71  0   0   B   72  0   0   0   B   73  0   0   0   \n";
        
        String actual = game.toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void CrosswordConstructorTestEight()
    {
        cells = new boolean[][] {
        {false,false,false,false,false,true,false,false,false,true,false,false,false,false,false},
        {false,false,false,false,false,true,false,false,false,true,false,false,false,false,false},
        {false,false,false,false,false,true,false,false,false,true,false,false,false,false,false},
        {false,false,false,false,false,false,false,false,false,false,true,true,false,false,false},
        {true,true,true,false,false,false,true,true,false,false,false,false,false,true,true},
        {false,false,false,false,true,false,false,false,true,false,false,false,false,false,false},
        {false,false,false,true,false,false,false,false,true,true,false,false,false,false,false},
        {false,false,false,true,false,false,false,false,false,false,false,true,false,false,false},
        {false,false,false,false,false,true,true,false,false,false,false,true,false,false,false},
        {false,false,false,false,false,false,true,false,false,false,true,false,false,false,false},
        {true,true,false,false,false,false,false,true,true,false,false,false,true,true,true},
        {false,false,false,true,true,false,false,false,false,false,false,false,false,false,false},
        {false,false,false,false,false,true,false,false,false,true,false,false,false,false,false},
        {false,false,false,false,false,true,false,false,false,true,false,false,false,false,false},
        {false,false,false,false,false,true,false,false,false,true,false,false,false,false,false},
        };
        game = new Crossword(cells);
        
        String expected =
        "1   2   3   4   5   B   6   7   8   B   9   10  11  12  13  \n" +
        "14  0   0   0   0   B   15  0   0   B   16  0   0   0   0   \n" +
        "17  0   0   0   0   B   18  0   0   B   19  0   0   0   0   \n" +
        "20  0   0   0   0   21  0   0   0   22  B   B   23  0   0   \n" +
        "B   B   B   24  0   0   B   B   25  0   26  27  0   B   B   \n" +
        "28  29  30  0   B   31  32  33  B   34  0   0   0   35  36  \n" +
        "37  0   0   B   38  0   0   0   B   B   39  0   0   0   0   \n" +
        "40  0   0   B   41  0   0   0   42  43  0   B   44  0   0   \n" +
        "45  0   0   46  0   B   B   47  0   0   0   B   48  0   0   \n" +
        "49  0   0   0   0   50  B   51  0   0   B   52  0   0   0   \n" +
        "B   B   53  0   0   0   54  B   B   55  56  0   B   B   B   \n" +
        "57  58  0   B   B   59  0   60  61  0   0   0   62  63  64  \n" +
        "65  0   0   66  67  B   68  0   0   B   69  0   0   0   0   \n" +
        "70  0   0   0   0   B   71  0   0   B   72  0   0   0   0   \n" +
        "73  0   0   0   0   B   74  0   0   B   75  0   0   0   0   \n";
        String actual = game.toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void CrosswordConstructorTestNine()
    {
        cells = new boolean[][] {
        {false,false,false,false,false,true,false,false,false,false,false,true,false,false,false},
        {false,false,false,false,false,true,false,false,false,false,false,true,false,false,false},
        {false,false,false,false,false,false,false,false,false,false,false,true,false,false,false},
        {true,true,true,true,true,false,false,false,true,true,false,false,false,true,true},
        {false,false,false,true,false,false,false,false,false,false,false,false,false,false,false},
        {false,false,false,false,false,true,false,false,false,false,true,false,false,false,false},
        {false,false,false,false,false,true,false,false,false,false,false,true,false,false,false},
        {true,true,false,false,false,false,true,true,true,false,false,false,false,true,true},
        {false,false,false,true,false,false,false,false,false,true,false,false,false,false,false},
        {false,false,false,false,true,false,false,false,false,true,false,false,false,false,false},
        {false,false,false,false,false,false,false,false,false,false,false,true,false,false,false},
        {true,true,false,false,false,true,true,false,false,false,true,true,true,true,true},
        {false,false,false,true,false,false,false,false,false,false,false,false,false,false,false},
        {false,false,false,true,false,false,false,false,false,true,false,false,false,false,false},
        {false,false,false,true,false,false,false,false,false,true,false,false,false,false,false},
        };
        game = new Crossword(cells);
        
        String expected =
        "1   2   3   4   5   B   6   7   8   9   10  B   11  12  13  \n" +
        "14  0   0   0   0   B   15  0   0   0   0   B   16  0   0   \n" +
        "17  0   0   0   0   18  0   0   0   0   0   B   19  0   0   \n" +
        "B   B   B   B   B   20  0   0   B   B   21  22  0   B   B   \n" +
        "23  24  25  B   26  0   0   0   27  28  0   0   0   29  30  \n" +
        "31  0   0   32  0   B   33  0   0   0   B   34  0   0   0   \n" +
        "35  0   0   0   0   B   36  0   0   0   37  B   38  0   0   \n" +
        "B   B   39  0   0   40  B   B   B   41  0   42  0   B   B   \n" +
        "43  44  0   B   45  0   46  47  48  B   49  0   0   50  51  \n" +
        "52  0   0   53  B   54  0   0   0   B   55  0   0   0   0   \n" +
        "56  0   0   0   57  0   0   0   0   58  0   B   59  0   0   \n" +
        "B   B   60  0   0   B   B   61  0   0   B   B   B   B   B   \n" +
        "62  63  0   B   64  65  66  0   0   0   67  68  69  70  71  \n" +
        "72  0   0   B   73  0   0   0   0   B   74  0   0   0   0   \n" +
        "75  0   0   B   76  0   0   0   0   B   77  0   0   0   0   \n";
        String actual = game.toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void CrosswordConstructorTestTen()
    {
        cells = new boolean[][] {
        {false,false,false,true,true,false,false,false,false,false,true,true,false,false,false},
        {false,false,false,false,true,false,false,false,false,false,true,false,false,false,false},
        {false,false,false,false,true,false,false,false,false,false,true,false,false,false,false},
        {false,false,false,false,false,false,false,false,true,false,false,false,false,false,false},
        {true,true,true,false,false,false,false,true,false,false,false,false,true,true,true},
        {false,false,false,false,false,false,true,false,false,false,false,false,false,false,false},
        {false,false,false,false,false,true,false,false,false,false,true,false,false,false,false},
        {false,false,false,false,true,false,false,false,false,false,true,false,false,false,false},
        {false,false,false,false,true,false,false,false,false,true,false,false,false,false,false},
        {false,false,false,false,false,false,false,false,true,false,false,false,false,false,false},
        {true,true,true,false,false,false,false,true,false,false,false,false,true,true,true},
        {false,false,false,false,false,false,true,false,false,false,false,false,false,false,false},
        {false,false,false,false,true,false,false,false,false,false,true,false,false,false,false},
        {false,false,false,false,true,false,false,false,false,false,true,false,false,false,false},
        {false,false,false,true,true,false,false,false,false,false,true,true,false,false,false}
        };
        game = new Crossword(cells);
        
        String expected =
        "1   2   3   B   B   4   5   6   7   8   B   B   9   10  11  \n" +
        "12  0   0   13  B   14  0   0   0   0   B   15  0   0   0   \n" +
        "16  0   0   0   B   17  0   0   0   0   B   18  0   0   0   \n" +
        "19  0   0   0   20  0   0   0   B   21  22  0   0   0   0   \n" +
        "B   B   B   23  0   0   0   B   24  0   0   0   B   B   B   \n" +
        "25  26  27  0   0   0   B   28  0   0   0   0   29  30  31  \n" +
        "32  0   0   0   0   B   33  0   0   0   B   34  0   0   0   \n" +
        "35  0   0   0   B   36  0   0   0   0   B   37  0   0   0   \n" +
        "38  0   0   0   B   39  0   0   0   B   40  0   0   0   0   \n" +
        "41  0   0   0   42  0   0   0   B   43  0   0   0   0   0   \n" +
        "B   B   B   44  0   0   0   B   45  0   0   0   B   B   B   \n" +
        "46  47  48  0   0   0   B   49  0   0   0   0   50  51  52  \n" +
        "53  0   0   0   B   54  55  0   0   0   B   56  0   0   0   \n" +
        "57  0   0   0   B   58  0   0   0   0   B   59  0   0   0   \n" +
        "60  0   0   B   B   61  0   0   0   0   B   B   62  0   0   \n";
        String actual = game.toString();
        assertEquals(expected, actual);
    }
}