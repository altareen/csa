/**
|-------------------------------------------------------------------------------
| Crossword.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 5, 2020
|
| This program implements the coloring scheme and numbering pattern on a
| crossword puzzle.
|
*/

public class Crossword
{
    private Square[][] puzzle;
    
    public Crossword(boolean[][] blackSquares)
    {
        // Part (b): YOUR CODE HERE
        
    }
    
    public boolean toBeLabeled(int r, int c, boolean[][] blackSquares)
    {
        // Part (a): YOUR CODE HERE
        
    }
    
    public String toString()
    {
        String result = "";
        for (int row = 0; row < puzzle.length; row++)
        {
            for (int col = 0; col < puzzle[0].length; col++)
            {
                result += puzzle[row][col].toString() + "  ";
                if (puzzle[row][col].getNumber() < 10)
                    result += " ";
            }
            result += "\n";
        }
        return result;
    }
}