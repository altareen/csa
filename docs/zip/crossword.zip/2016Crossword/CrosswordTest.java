/**
|-------------------------------------------------------------------------------
| CrosswordTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 5, 2020
|
| This program is the test bench for Crossword.java
|
| Do not alter the contents of this file.
|
*/

public class CrosswordTest
{
    public static void main(String[] args)
    {
        boolean[][] cells = {
        {true, false, false, true, true, true, false, false, false},
        {false, false, false, false, true, false, false, false, false},
        {false, false, false, false, false, false, true, true, true},
        {false, false, true, false, false, false, true, false, false},
        {true, true, true, false, false, false, false, false, false},
        {false, false, false, false, true, false, false, false, false},
        {false, false, false, true, true, true, false, false, true}};
        
        Crossword game = new Crossword(cells);
        
        System.out.println("Part (a):");
        boolean result = game.toBeLabeled(0, 8, cells);
        System.out.println("Positive number at row=0, col=8? Should be true: " + result);
        result = game.toBeLabeled(1, 3, cells);
        System.out.println("Positive number at row=1, col=3? Should be true: " + result);
        result = game.toBeLabeled(2, 7, cells);
        System.out.println("Positive number at row=2, col=7? Should be false: " + result);
        result = game.toBeLabeled(3, 5, cells);
        System.out.println("Positive number at row=3, col=5? Should be false: " + result);
        
        System.out.println();
        System.out.println("Part (b):");
        System.out.println("Puzzle initialized from the Crossword constructor:");
        System.out.println(game);
    }
}