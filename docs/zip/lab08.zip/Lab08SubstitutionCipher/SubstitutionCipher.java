/**
|-------------------------------------------------------------------------------
| SubstitutionCipher.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Nov 21, 2019
|
| This program encrypts a message using the substitution cipher.
|
*/

public class SubstitutionCipher
{
    public static String encrypt(String message, String key)
    {
        String alpha = "abcdefghijklmnopqrstuvwxyz";
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        String result = encrypt("hello", "jtrekyavogdxpsncuizlfbmwhq");
        System.out.println(result);
    }
}
