/**
|-------------------------------------------------------------------------------
| SubstitutionCipherJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Nov 21, 2019
|
| This is the JUnit test bench for SubstitutionCipher.java
| Do not alter the contents of this file.
|
*/

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class SubstitutionCipherJUnitTest
{
    @Test
    public void testOne()
    {
        String expected = "vkxxn";
        String actual = SubstitutionCipher.encrypt("hello", "jtrekyavogdxpsncuizlfbmwhq");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testTwo()
    {
        String expected = "tuncrejmjmcrenx";
        String actual = SubstitutionCipher.encrypt("gonewiththewind", "yfpxcatmelosqnugihwjbkrzdv");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testThree()
    {
        String expected = "rwllhwgxenjngxpyyo";
        String actual = SubstitutionCipher.encrypt("pizzaisthebestfood", "hjdonpkewabuqfyrmigxtzscvl");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testFour()
    {
        String expected = "ocvijvypvajijgeqk";
        String actual = SubstitutionCipher.encrypt("greatexpectations", "iuaxvrowghdmbqeplckjftnysz");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testFive()
    {
        String expected = "bylomypqywphqomayuypwbjyl";
        String actual = SubstitutionCipher.encrypt("besuretoeatyourvegetables", "wbrgysuxzedjtiqnfmlpoavkhc");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSix()
    {
        String expected = "reidioenqeyroejthgpgnhjfxdlshhjf";
        String actual = SubstitutionCipher.encrypt("wearahelmetwhenbicyclingorskiing", "itgwevfohmsnqjxuadlyzbrcpk");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSeven()
    {
        String expected = "exwanzlkkrbfahfbmlodqfkkndwqltfge";
        String actual = SubstitutionCipher.encrypt("studywellinadvanceforallyourexams", "fpmalovsryjkgbdciqexwhztnu");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testEight()
    {
        String expected = "dydqvyivolivksophkvk";
        String actual = SubstitutionCipher.encrypt("awakewhenthesunrises", "dfmzvgeihnqjcortxpklsbywua");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testNine()
    {
        String expected = "dfuqkzryszvwszduvdzwd";
        String actual = SubstitutionCipher.encrypt("slumberwhenthesunsets", "mkgxzojschnfqvipardwulybte");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testTen()
    {
        String expected = "qjitkcrytmswgmyvfwggyyvtquoify";
        String actual = SubstitutionCipher.encrypt("drinkplentyofteacoffeeandjuice", "vnfqygeliukratwcbjxmohdzsp");
        assertEquals(expected, actual);
    }
}
