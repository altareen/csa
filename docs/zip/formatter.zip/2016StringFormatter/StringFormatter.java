/**
|-------------------------------------------------------------------------------
| StringFormatter.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 7, 2020
|
| This program produces a formatted string of a specific length.
|
*/

import java.util.*;

public class StringFormatter
{
    public static int totalLetters(ArrayList<String> wordList)
    {
        // Part (a): YOUR CODE HERE
        
    }
    
    public static int basicGapWidth(ArrayList<String> wordList, int formattedLen)
    {
        // Part (b): YOUR CODE HERE
        
    }
    
    public static int leftoverSpaces(ArrayList<String> wordList, int formattedLen)
    {
        int letters = totalLetters(wordList);
        int gapSize = basicGapWidth(wordList, formattedLen);
        int numGaps = wordList.size()-1;
        int spaces = formattedLen - letters;
        return spaces - (numGaps*gapSize);
    }
    
    public static String format(ArrayList<String> wordList, int formattedLen)
    {
        // Part (c): YOUR CODE HERE
        
    }
}