/**
|-------------------------------------------------------------------------------
| SkyView.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 1, 2020
|
| This program analyzes telescope data.
|
*/

public class SkyView
{
    private double[][] view;

    public SkyView(int numRows, int numCols, double[] scanned)
    {
        // Part (a): YOUR CODE HERE
        
    }

    public double getAverage(int startRow, int endRow, int startCol, int endCol)
    {
        // Part (b): YOUR CODE HERE
        
    }
    
    public double[][] getView()
    {
        return view;
    }
    
    public String toString()
    {
        String result = "";
        for (double[] row : view)
        {
            for (double item : row)
            {
                result += item + " ";
            }
            result += "\n";
        }
        return result;
    }
}