/**
|-------------------------------------------------------------------------------
| SkyViewJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 1, 2020
|
| This program is the JUnit test bench for SkyView.java
|
| Do not alter the contents of this file.
|
*/

import junit.framework.JUnit4TestAdapter;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SkyViewJUnitTest
{
    private double[] scanned;
    private SkyView scope;
   
    @After
    public void runAfterEachTest()
    {
        scanned = null;
        scope = null;
    }
    
    @Test
    public void constructorTestOne()
    {
        scanned = new double[]{0.3,0.7,0.8,0.4,1.4,1.1,0.2,0.5,0.1,1.6,0.6,0.9};
        scope = new SkyView(4, 3, scanned);
        double[][] expected = { {0.3, 0.7, 0.8},
                                {1.1, 1.4, 0.4},
                                {0.2, 0.5, 0.1},
                                {0.9, 0.6, 1.6}}; 
        double[][] actual = scope.getView();
        assertArrayEquals(expected, actual);
    }
    
    @Test
    public void constructorTestTwo()
    {
        scanned = new double[]{0.3,0.7,0.8,0.4,1.4,1.1};
        scope = new SkyView(3, 2, scanned);
        double[][] expected = { {0.3, 0.7},
                                {0.4, 0.8},
                                {1.4, 1.1}};
        double[][] actual = scope.getView();
        assertArrayEquals(expected, actual);
    }
    
    @Test
    public void constructorTestThree()
    {
        scanned = new double[]{9.0,9.8,2.3,4.7,4.1,9.0,6.5,6.9};
        scope = new SkyView(2, 4, scanned);
        double[][] expected = { {9.0, 9.8, 2.3, 4.7},
                                {6.9, 6.5, 9.0, 4.1}};
        double[][] actual = scope.getView();
        assertArrayEquals(expected, actual);
    }
    
    @Test
    public void constructorTestFour()
    {
        scanned = new double[]{4.8,1.8,3.9,1.6,2.0,3.4,9.4,2.5,5.1,4.7,4.3,1.7,8.0,3.5,6.1,3.5};
        scope = new SkyView(4, 4, scanned);
        double[][] expected = { {4.8, 1.8, 3.9, 1.6},
                                {2.5, 9.4, 3.4, 2.0},
                                {5.1, 4.7, 4.3, 1.7},
                                {3.5, 6.1, 3.5, 8.0}};
        double[][] actual = scope.getView();
        assertArrayEquals(expected, actual);
    }
    
    @Test
    public void constructorTestFive()
    {
        scanned = new double[]{4.1,4.8,3.3,9.0,7.5,1.5,8.9,4.0,6.0,9.5,2.4,4.8,4.6,7.0,7.4};
        scope = new SkyView(3, 5, scanned);
        double[][] expected = { {4.1, 4.8, 3.3, 9.0, 7.5},
                                {9.5, 6.0, 4.0, 8.9, 1.5},
                                {2.4, 4.8, 4.6, 7.0, 7.4}};
        double[][] actual = scope.getView();
        assertArrayEquals(expected, actual);
    }
    
    @Test
    public void getAverageTestSix()
    {
        scanned = new double[]{0.3,0.7,0.8,0.4,1.4,1.1,0.2,0.5,0.1,1.6,0.6,0.9};
        scope = new SkyView(4, 3, scanned);
        double expected = 0.8;
        double actual = scope.getAverage(1, 2, 0, 1);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void getAverageTestSeven()
    {
        scanned = new double[]{0.3,0.7,0.8,0.4,1.4,1.1};
        scope = new SkyView(3, 2, scanned);
        double expected = 0.925;
        double actual = scope.getAverage(1, 2, 0, 1);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void getAverageTestEight()
    {
        scanned = new double[]{9.0,9.8,2.3,4.7,4.1,9.0,6.5,6.9};
        scope = new SkyView(2, 4, scanned);
        double expected = 7.25;
        double actual = scope.getAverage(0, 1, 0, 2);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void getAverageTestNine()
    {
        scanned = new double[]{4.8,1.8,3.9,1.6,2.0,3.4,9.4,2.5,5.1,4.7,4.3,1.7,8.0,3.5,6.1,3.5};
        scope = new SkyView(4, 4, scanned);
        double expected = 4.65;
        double actual = scope.getAverage(2, 3, 1, 2);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void getAverageTestTen()
    {
        scanned = new double[]{4.1,4.8,3.3,9.0,7.5,1.5,8.9,4.0,6.0,9.5,2.4,4.8,4.6,7.0,7.4};
        scope = new SkyView(3, 5, scanned);
        double expected = 5.7;
        double actual = scope.getAverage(0, 1, 2, 4);
        assertEquals(expected, actual, 0.1);
    }
}