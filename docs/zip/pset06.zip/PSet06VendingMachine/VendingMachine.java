/**
|-------------------------------------------------------------------------------
| VendingMachine.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Oct 15, 2019
|
| This program simulates a simple change maker for a vending machine.
|
*/

public class VendingMachine
{
    public static int dispenseChange(int quarters, int dimes, int nickels, int cost, int payment)
    {
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        int result = dispenseChange(5, 5, 5, 160, 200);
        System.out.println(result);
    }
}