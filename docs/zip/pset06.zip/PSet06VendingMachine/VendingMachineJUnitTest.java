/**
|-------------------------------------------------------------------------------
| VendingMachineJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Oct 15, 2019
|
| This is the JUnit test bench for VendingMachine.java
| Do not alter the contents of this file.
|
*/

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class VendingMachineJUnitTest
{
    @Test
    public void testCaseOne()
    {
        int expected = 3;
        int actual = VendingMachine.dispenseChange(5, 5, 5, 160, 200);
        assertEquals(expected, actual);
    }

    @Test
    public void testCaseTwo()
    {
        int expected = 15;
        int actual = VendingMachine.dispenseChange(20, 0, 0, 125, 500);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testCaseThree()
    {
        int expected = 9;
        int actual = VendingMachine.dispenseChange(0, 10, 0, 210, 300);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testCaseFour()
    {
        int expected = 58;
        int actual = VendingMachine.dispenseChange(0, 0, 60, 235, 525);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testCaseFive()
    {
        int expected = 17;
        int actual = VendingMachine.dispenseChange(6, 5, 10, 195, 425);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testCaseSix()
    {
        int expected = 72;
        int actual = VendingMachine.dispenseChange(10, 20, 50, 235, 895);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testCaseSeven()
    {
        int expected = 54;
        int actual = VendingMachine.dispenseChange(19, 82, 23, 675, 1495);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testCaseEight()
    {
        int expected = 113;
        int actual = VendingMachine.dispenseChange(12, 100, 1, 1855, 3160);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testCaseNine()
    {
        int expected = 182;
        int actual = VendingMachine.dispenseChange(100, 1, 83, 2870, 5785);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testCaseTen()
    {
        int expected = 362;
        int actual = VendingMachine.dispenseChange(2, 287, 157, 5285, 8570);
        assertEquals(expected, actual);
    }
}