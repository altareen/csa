/**
|-------------------------------------------------------------------------------
| Fahrenheit
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: May 20, 2019
|
| This program converts celsius to fahrenheit.
|
*/

public class Fahrenheit
{
    public static double calculateFahrenheit(double celsius)
    {
        // Perform the conversion from celsius to fahrenheit.
        // YOUR CODE HERE
        
        
        return fahrenheit;
    }
    
    public static void main(String[] args)
    {
        double result = calculateFahrenheit(100.0);
        System.out.println(result);
    }
}
