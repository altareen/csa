/**
|-------------------------------------------------------------------------------
| ArrayTester.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 11, 2020
|
| This program implements mathematical array operations.
|
*/

public class ArrayTester
{
    public static int[] getColumn(int[][] arr2D, int c)
    {
        // Part (a): YOUR CODE HERE
        
    }
    
    public static boolean hasAllValues(int[] arr1, int[] arr2)
    {
        boolean exists = false;
        for (int i = 0; i < arr1.length; i++)
        {
            exists = false;
            for (int j = 0; j < arr2.length; j++)
            {
                if (arr1[i] == arr2[j])
                {
                    exists = true;
                }
            }
            if (exists == false)
            {
                return false;
            }
        }
        return true;
    }
    
    public static boolean containsDuplicates(int[] arr)
    {
        for (int i = 0; i < arr.length-1; i++)
        {
            for (int j = i+1; j < arr.length; j++)
            {
                if (arr[i] == arr[j])
                {
                    return true;
                }
            }
        }
        return false;
    }
    
    public static boolean isLatin(int[][] square)
    {
        // Part (b): YOUR CODE HERE
        
    }
}