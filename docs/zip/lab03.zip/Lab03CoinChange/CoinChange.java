/**
|-------------------------------------------------------------------------------
| CoinChange.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Oct 11, 2019
|
| This program determines the minimum number of coins for a particular value.
|
*/

public class CoinChange
{
    public static int minimumCoins(int cents)
    {
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        int result = minimumCoins(41);
        System.out.println(result);
    }
}
