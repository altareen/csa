/**
|-------------------------------------------------------------------------------
| CoinChangeJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Oct 11, 2019
|
| This is the JUnit test bench for CoinChange.java
| Do not alter the contents of this file.
|
*/

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class CoinChangeJUnitTest
{
    @Test
    public void testOne()
    {
        int expected = 4;
        int actual = CoinChange.minimumCoins(41);
        assertEquals(expected, actual);
    }

    @Test
    public void testTwo()
    {
        int expected = 1;
        int actual = CoinChange.minimumCoins(1);
        assertEquals(expected, actual);
    }

    @Test
    public void testThree()
    {
        int expected = 2;
        int actual = CoinChange.minimumCoins(15);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testFour()
    {
        int expected = 7;
        int actual = CoinChange.minimumCoins(160);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testFive()
    {
        int expected = 92;
        int actual = CoinChange.minimumCoins(2300);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSix()
    {
        int expected = 18;
        int actual = CoinChange.minimumCoins(420);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSeven()
    {
        int expected = 238;
        int actual = CoinChange.minimumCoins(5926);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testEight()
    {
        int expected = 320;
        int actual = CoinChange.minimumCoins(7932);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testNine()
    {
        int expected = 422;
        int actual = CoinChange.minimumCoins(10454);
        assertEquals(expected, actual);
    }
    
    @Test
    public void testTen()
    {
        int expected = 926;
        int actual = CoinChange.minimumCoins(23078);
        assertEquals(expected, actual);
    }
}
