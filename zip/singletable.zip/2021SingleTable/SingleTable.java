/**
|-------------------------------------------------------------------------------
| SingleTable.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 12, 2022
|
| This program represents a single table at a restaurant.
|
*/

public class SingleTable
{
    // instance variables
    private int numSeats;
    private int height;
    private double viewQuality;
    
    public SingleTable(int n, int h, double v)
    {
        numSeats = n;
        height = h;
        viewQuality = v;
    }
    
    public int getNumSeats()
    {
        return numSeats;
    }
    
    public int getHeight()
    {
        return height;
    }
    
    public double getViewQuality()
    {
        return viewQuality;
    }
    
    public void setViewQuality(double value)
    {
        viewQuality = value;
    }   
}