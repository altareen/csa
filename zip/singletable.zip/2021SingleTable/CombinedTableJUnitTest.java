/**
|-------------------------------------------------------------------------------
| CombinedTableJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 12, 2022
|
| This is the JUnit test bench for CombinedTable.java
| Do not alter the contents of this file.
|
*/

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class CombinedTableJUnitTest
{
    private SingleTable t1;
    private SingleTable t2;
    private SingleTable t3;
    private CombinedTable c1;
    private CombinedTable c2;

    @BeforeEach
    public void runBeforeEachTest()
    {
        t1 = new SingleTable(4, 74, 60.0);
        t2 = new SingleTable(8, 74, 70.0);
        t3 = new SingleTable(12, 76, 75.0);
        c1 = new CombinedTable(t1, t2);
        c2 = new CombinedTable(t2, t3);
    }
    
    @AfterEach
    public void runAfterEachTest()
    {
        t1 = null;
        t2 = null;
        t3 = null;
        c1 = null;
        c2 = null;
    }
    
    @Test
    public void canSeatTestOne()
    {
        assertTrue(c1.canSeat(9));
    }
    
    @Test
    public void canSeatTestTwo()
    {
        assertFalse(c1.canSeat(11));
    }
    
    @Test
    public void getDesirabilityTestThree()
    {
        double expected = 65.0;
        double actual = c1.getDesirability();
        assertEquals(expected, actual);
    }
    
    @Test
    public void canSeatTestFour()
    {
        assertTrue(c2.canSeat(18));
    }
    
    @Test
    public void getDesirabilityTestFive()
    {
        double expected = 62.5;
        double actual = c2.getDesirability();
        assertEquals(expected, actual);
    }
    
    @Test
    public void getDesirabilityTestSix()
    {
        t2.setViewQuality(80);
        double expected = 67.5;
        double actual = c2.getDesirability();
        assertEquals(expected, actual);
    }
}