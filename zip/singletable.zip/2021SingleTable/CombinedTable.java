/**
|-------------------------------------------------------------------------------
| CombinedTable.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 12, 2022
|
| This program represents a combined table at a restaurant.
|
*/

public class CombinedTable
{
    // YOUR CODE HERE
    
}