/**
|-------------------------------------------------------------------------------
| SmoothSignal.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Oct 31, 2019
|
| This program smoothes an audio signal by averaging intensities.
|
*/

import java.util.*;

public class SmoothSignal
{
    public static int[] levelling(int[] audio)
    {
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        int[] signal = {1, 5, 4, 5, 7, 6, 8, 6, 5, 4, 5, 4};
        
        // compute the smoothed value for each cell of the array signal
        int[] result = levelling(signal);

        // display the array: result
        System.out.println(Arrays.toString(result));
    }
}
