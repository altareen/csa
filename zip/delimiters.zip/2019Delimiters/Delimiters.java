/**
|-------------------------------------------------------------------------------
| Delimiters.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Dec 15, 2019
|
| This program checks for the presence of valid delimiters.
|
*/

import java.util.*;
public class Delimiters
{
    // instance variables
    private String openDel;
    private String closeDel;
    
    // constructors
    public Delimiters(String open, String close)
    {
        openDel = open;
        closeDel = close;
    }
    
    public ArrayList<String> getDelimitersList(String[] tokens)
    {
        // YOUR CODE HERE
        
    }
    
    public boolean isBalanced(ArrayList<String> delimiters)
    {
        // YOUR CODE HERE
        
    }
}
