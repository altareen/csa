/**
|-------------------------------------------------------------------------------
| VigenereCipher.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Nov 22, 2019
|
| This program encrypts a message using the vigenere cipher.
|
*/

public class VigenereCipher
{
    public static String encrypt(String message, String key)
    {
        String alpha = "abcdefghijklmnopqrstuvwxyz";
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        String result = encrypt("hello", "abc");
        System.out.println(result);
    }
}
