/**
|-------------------------------------------------------------------------------
| VigenereCipherJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Nov 22, 2019
|
| This is the JUnit test bench for VigenereCipher.java
| Do not alter the contents of this file.
|
*/

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class VigenereCipherJUnitTest
{
    @Test
    public void testOne()
    {
        String expected = "hfnlp";
        String actual = VigenereCipher.encrypt("hello", "abc");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testTwo()
    {
        String expected = "neghzfavhufpcfxbtgzrwepoz";
        String actual = VigenereCipher.encrypt("meetmeattheparkatelevenam", "bacon");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testThree()
    {
        String expected = "xpwntkmugeamuwelejpgkise";
        String actual = VigenereCipher.encrypt("electricvehiclesaregreat", "tesla");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testFour()
    {
        String expected = "uoammwgsrtmkhvshbyoewusubuanxcrd";
        String actual = VigenereCipher.encrypt("lunchispizzacheeseburgersandsoda", "junkfood");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testFive()
    {
        String expected = "xeapbfmzazvowmhfminxzeltjyk";
        String actual = VigenereCipher.encrypt("caulifloweristhebesttasting", "vegetable");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSix()
    {
        String expected = "deeetymoeltvvesetmyerjlmaigmxekkyeqpum";
        String actual = VigenereCipher.encrypt("cellphonesaregreatuntilthepowerrunsout", "battery");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSeven()
    {
        String expected = "esvhlocjoohfdrrgvzigrbdrrvbnxpnrjjhnhxltauoz";
        String actual = VigenereCipher.encrypt("readabookduringtheeveninginsteadofwatchingtv", "novel");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testEight()
    {
        String expected = "lhvxtwenoaihvbihcfvdlerbawofnesjrmktt";
        String actual = VigenereCipher.encrypt("whentheweatheriscoldwearahoodedjacket", "parka");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testNine()
    {
        String expected = "upgpqlhtitchweuaqwqfgbvewewifdgpahlfzg";
        String actual = VigenereCipher.encrypt("theroadsareflatsoyoucancycleeverywhere", "bicycle");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testTen()
    {
        String expected = "vqxrvpzfmgeuiycacztkscxsxgszrrehyevdqpcsymtfr";
        String actual = VigenereCipher.encrypt("bewareofsuddenrainstormsduringthesummerseason", "umbrella");
        assertEquals(expected, actual);
    }
}
