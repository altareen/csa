/**
|-------------------------------------------------------------------------------
| BarCode.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Feb 04, 2020
|
| This program determines whether a particular bar code pattern is valid.
|
*/

public class BarCode
{
    public static String validate(String barPattern)
    {
        String[] left = {"0001101", "0011001", "0010011", "0111101", "0100011",
                         "0110001", "0101111", "0111011", "0110111", "0001011"};
        String[] right = {"1110010", "1100110", "1101100", "1000010", "1011100",
                          "1001110", "1010000", "1000100", "1001000", "1110100"};
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        String product = "10100011010011001001001100011010001101000110101010111001011100101101100100001011100101011100101";
        String result = validate(product);
        System.out.println(result);
    }
}