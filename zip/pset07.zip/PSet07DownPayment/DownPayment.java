/**
|-------------------------------------------------------------------------------
| DownPayment.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Oct 20, 2019
|
| This program determines the number of months required for a down payment.
|
*/

public class DownPayment
{
    public static int savingsDuration(double annualSalary, double percentSaved, double totalCost, double payRaise)
    {
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        int result = savingsDuration(120000, 0.05, 500000, 0.03);
        System.out.println(result);
    }
}
