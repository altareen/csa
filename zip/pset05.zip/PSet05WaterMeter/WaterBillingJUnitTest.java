/**
|-------------------------------------------------------------------------------
| WaterBillingJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Oct 08, 2019
|
| This is the JUnit test bench for WaterBilling.java
| Do not alter the contents of this file.
|
*/

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class WaterBillingJUnitTest
{
    @Test
    public void testCaseOne()
    {
        double expected = 5.0066;
        double actual = WaterBilling.calculateBill("residential", 444400003, 444400135);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseTwo()
    {
        double expected = 5.03415;
        double actual = WaterBilling.calculateBill("residential", 699562838, 699563521);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseThree()
    {
        double expected = 9.6522;
        double actual = WaterBilling.calculateBill("residential", 769005304, 769098348);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseFour()
    {
        double expected = 1000.0;
        double actual = WaterBilling.calculateBill("commercial", 333123874, 333125349);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseFive()
    {
        double expected = 1055.323125;
        double actual = WaterBilling.calculateBill("commercial", 582776462, 585389387);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseSix()
    {
        double expected = 1190.145825;
        double actual = WaterBilling.calculateBill("commercial", 480937451, 488943284);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseSeven()
    {
        double expected = 1000.0;
        double actual = WaterBilling.calculateBill("industrial", 727231412, 727232387);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseEight()
    {
        double expected = 2000.0;
        double actual = WaterBilling.calculateBill("industrial", 210453226, 210939213);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseNine()
    {
        double expected = 4381.02715;
        double actual = WaterBilling.calculateBill("industrial", 903806449, 959847535);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseTen()
    {
        double expected = 3000.426425;
        double actual = WaterBilling.calculateBill("industrial", 795112816, 795929873);
        assertEquals(expected, actual, 2);
    }
}

