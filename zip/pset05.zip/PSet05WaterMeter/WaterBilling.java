/**
|-------------------------------------------------------------------------------
| WaterBilling.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Oct 08, 2019
|
| This program determines the amount of a customer's water bill.
|
*/

public class WaterBilling
{
    public static double calculateBill(String customer, double begin, double end)
    {
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        double result = calculateBill("residential", 444400003, 444400135);
        System.out.println(result);
    }
}