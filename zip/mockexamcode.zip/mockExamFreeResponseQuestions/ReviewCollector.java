/**
|-------------------------------------------------------------------------------
| ReviewCollector.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 9, 2020
|
| This program represents a collection of reviews to be analyzed.
|
*/

import java.util.*;

public class ReviewCollector
{
    private ArrayList<ProductReview> reviewList;
    private ArrayList<String> productList;
    
    public ReviewCollector()
    {
        reviewList = new ArrayList<ProductReview>();
        productList = new ArrayList<String>();
    }
    
    public ArrayList<ProductReview> getReviews()
    {
        return reviewList;
    }
    
    public ArrayList<String> getProducts()
    {
        return productList;
    }
    
    public void addReview(ProductReview prodReview)
    {
        // Part (a): YOUR CODE HERE
        
    }
    
    public int getNumGoodReviews(String prodName)
    {
        // Part (b): YOUR CODE HERE
        
    }
}