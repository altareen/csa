/**
|-------------------------------------------------------------------------------
| CheckDigit.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 9, 2020
|
| This program checks for errors in data transmissions.
|
*/

public class CheckDigit
{
    public static int getCheck(int num)
    {
        // Part (a): YOUR CODE HERE
        
    }
    
    public static boolean isValid(int numWithCheckDigit)
    {
        // Part (b): YOUR CODE HERE
        
    }
    
    public static int getNumberOfDigits(int num)
    {
        return Integer.toString(num).length();
    }
    
    public static int getDigit(int num, int n)
    {
        String tally = Integer.toString(num);
        return Integer.parseInt(tally.substring(n-1, n));
    }
}