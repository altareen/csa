/**
|-------------------------------------------------------------------------------
| ProductReview.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 9, 2020
|
| This program represents a product name and a review of that product.
|
*/

public class ProductReview
{
    private String name;
    private String review;
    
    public ProductReview(String pName, String pReview)
    {
        name = pName;
        review = pReview;
    }
    
    public String getName()
    {
        return name;
    }
    
    public String getReview()
    {
        return review;
    }
    
    public String toString()
    {
        return "(" + name + " : " + review + ")";
    }
}