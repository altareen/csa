/**
|-------------------------------------------------------------------------------
| ReviewCollectorJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 14, 2020
|
| This is the JUnit test bench for ReviewCollector.java
|
| Do not alter the contents of this file.
|
*/

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import java.util.*;

public class ReviewCollectorJUnitTest
{
    private ReviewCollector analytics;
    
    @Before
    public void runBeforeEachTest()
    {
        analytics = new ReviewCollector();
    }
    
    @After
    public void runAfterEachTest()
    {
        analytics = null;
    }
    
    @Test
    public void addReviewTestOne()
    {
        analytics.addReview(new ProductReview("Laptop", "Works well."));
        analytics.addReview(new ProductReview("Phone", "Has the best sound."));
        analytics.addReview(new ProductReview("Bicycle", "Smooth ride."));
        analytics.addReview(new ProductReview("Phone", "The best handset around."));
        analytics.addReview(new ProductReview("Bicycle", "Good handling."));
        analytics.addReview(new ProductReview("Mouse", "The range is the best."));
        
        ArrayList<ProductReview> feedback = new ArrayList<ProductReview>();
        feedback.add(new ProductReview("Laptop", "Works well."));
        feedback.add(new ProductReview("Phone", "Has the best sound."));
        feedback.add(new ProductReview("Bicycle", "Smooth ride."));
        feedback.add(new ProductReview("Phone", "The best handset around."));
        feedback.add(new ProductReview("Bicycle", "Good handling."));
        feedback.add(new ProductReview("Mouse", "The range is the best."));
        
        String expected = feedback.toString();
        String actual = analytics.getReviews().toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void addReviewTestTwo()
    {
        analytics.addReview(new ProductReview("Laptop", "Works well."));
        analytics.addReview(new ProductReview("Phone", "Has the best sound."));
        analytics.addReview(new ProductReview("Bicycle", "Smooth ride."));
        analytics.addReview(new ProductReview("Phone", "The best handset around."));
        analytics.addReview(new ProductReview("Bicycle", "Good handling."));
        analytics.addReview(new ProductReview("Mouse", "The range is the best."));
        
        ArrayList<String> inventory = new ArrayList<String>();
        inventory.add("Laptop");
        inventory.add("Phone");
        inventory.add("Bicycle");
        inventory.add("Mouse");
        
        String expected = inventory.toString();
        String actual = analytics.getProducts().toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void addReviewTestThree()
    {
        analytics.addReview(new ProductReview("Backpack", "This is the best value for money."));
        analytics.addReview(new ProductReview("Gloves", "Good fit, and nice texture."));
        analytics.addReview(new ProductReview("Backpack", "Nicely fitting and comfortable."));
        analytics.addReview(new ProductReview("Backpack", "One of the best packs I've seen."));
        analytics.addReview(new ProductReview("Charger", "Fast charging time for my phone."));
        analytics.addReview(new ProductReview("Backpack", "Has the best color."));
        analytics.addReview(new ProductReview("Backpack", "Holds my laptop and all my books."));
        analytics.addReview(new ProductReview("Printer", "Crisply printed pages, no smudges."));
        
        ArrayList<ProductReview> feedback = new ArrayList<ProductReview>();
        feedback.add(new ProductReview("Backpack", "This is the best value for money."));
        feedback.add(new ProductReview("Gloves", "Good fit, and nice texture."));
        feedback.add(new ProductReview("Backpack", "Nicely fitting and comfortable."));
        feedback.add(new ProductReview("Backpack", "One of the best packs I've seen."));
        feedback.add(new ProductReview("Charger", "Fast charging time for my phone."));
        feedback.add(new ProductReview("Backpack", "Has the best color."));
        feedback.add(new ProductReview("Backpack", "Holds my laptop and all my books."));
        feedback.add(new ProductReview("Printer", "Crisply printed pages, no smudges."));
        
        String expected = feedback.toString();
        String actual = analytics.getReviews().toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void addReviewTestFour()
    {
        analytics.addReview(new ProductReview("Backpack", "This is the best value for money."));
        analytics.addReview(new ProductReview("Gloves", "Good fit, and nice texture."));
        analytics.addReview(new ProductReview("Backpack", "Nicely fitting and comfortable."));
        analytics.addReview(new ProductReview("Backpack", "One of the best packs I've seen."));
        analytics.addReview(new ProductReview("Charger", "Fast charging time for my phone."));
        analytics.addReview(new ProductReview("Backpack", "Has the best color."));
        analytics.addReview(new ProductReview("Backpack", "Holds my laptop and all my books."));
        analytics.addReview(new ProductReview("Printer", "Crisply printed pages, no smudges."));
        
        ArrayList<String> inventory = new ArrayList<String>();
        inventory.add("Backpack");
        inventory.add("Gloves");
        inventory.add("Charger");
        inventory.add("Printer");
        
        String expected = inventory.toString();
        String actual = analytics.getProducts().toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void addReviewTestFive()
    {
        analytics.addReview(new ProductReview("Mask", "Nice comfortable fit."));
        analytics.addReview(new ProductReview("Humidifier", "Quiet, with good performance."));
        analytics.addReview(new ProductReview("Grill", "Cooks all my meals superbly."));
        analytics.addReview(new ProductReview("Mask", "Looks great, best value!"));
        analytics.addReview(new ProductReview("Mask", "This has the best color."));
        analytics.addReview(new ProductReview("Mask", "I look the best in this."));
        analytics.addReview(new ProductReview("Humidifier", "Needs water refilling often."));
        analytics.addReview(new ProductReview("Brush", "Nice handle, good bristles."));
        analytics.addReview(new ProductReview("Mask", "This fits the best."));
        analytics.addReview(new ProductReview("Mask", "The straps have the best fit."));
        
        ArrayList<String> inventory = new ArrayList<String>();
        inventory.add("Mask");
        inventory.add("Humidifier");
        inventory.add("Grill");
        inventory.add("Brush");
        
        String expected = inventory.toString();
        String actual = analytics.getProducts().toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void getNumGoodReviewsTestSix()
    {
        analytics.addReview(new ProductReview("Laptop", "Works well."));
        analytics.addReview(new ProductReview("Phone", "Has the best sound."));
        analytics.addReview(new ProductReview("Bicycle", "Smooth ride."));
        analytics.addReview(new ProductReview("Phone", "The best handset around."));
        analytics.addReview(new ProductReview("Bicycle", "Good handling."));
        analytics.addReview(new ProductReview("Mouse", "The range is the best."));
        
        int expected = 2;
        int actual = analytics.getNumGoodReviews("Phone");
        assertEquals(expected, actual);
    }
    
    @Test
    public void getNumGoodReviewsTestSeven()
    {
        analytics.addReview(new ProductReview("Backpack", "This is the best value for money."));
        analytics.addReview(new ProductReview("Gloves", "Good fit, and nice texture."));
        analytics.addReview(new ProductReview("Backpack", "Nicely fitting and comfortable."));
        analytics.addReview(new ProductReview("Backpack", "One of the best packs I've seen."));
        analytics.addReview(new ProductReview("Charger", "Fast charging time for my phone."));
        analytics.addReview(new ProductReview("Backpack", "Has the best color."));
        analytics.addReview(new ProductReview("Backpack", "Holds my laptop and all my books."));
        analytics.addReview(new ProductReview("Printer", "Crisply printed pages, no smudges."));
        
        int expected = 3;
        int actual = analytics.getNumGoodReviews("Backpack");
        assertEquals(expected, actual);
    }
    
    @Test
    public void getNumGoodReviewsTestEight()
    {
        analytics.addReview(new ProductReview("Mask", "Nice comfortable fit."));
        analytics.addReview(new ProductReview("Humidifier", "Quiet, with good performance."));
        analytics.addReview(new ProductReview("Grill", "Cooks all my meals superbly."));
        analytics.addReview(new ProductReview("Mask", "Looks great, best value!"));
        analytics.addReview(new ProductReview("Mask", "This has the best color."));
        analytics.addReview(new ProductReview("Mask", "I look the best in this."));
        analytics.addReview(new ProductReview("Humidifier", "Needs water refilling often."));
        analytics.addReview(new ProductReview("Brush", "Nice handle, good bristles."));
        analytics.addReview(new ProductReview("Mask", "This fits the best."));
        analytics.addReview(new ProductReview("Mask", "The straps have the best fit."));
        
        int expected = 5;
        int actual = analytics.getNumGoodReviews("Mask");
        assertEquals(expected, actual);
    }
    
    @Test
    public void getNumGoodReviewsTestNine()
    {
        analytics.addReview(new ProductReview("Sweater", "Comfortable fit, looks great!"));
        analytics.addReview(new ProductReview("Canteen", "This is the best water container."));
        analytics.addReview(new ProductReview("Canteen", "I like this the best."));
        analytics.addReview(new ProductReview("Napkins", "Great for big spills!"));
        analytics.addReview(new ProductReview("Jeans", "Looks great on me!"));
        analytics.addReview(new ProductReview("Canteen", "Keeps my water cool."));
        analytics.addReview(new ProductReview("Canteen", "This is best for water, not tea."));
        analytics.addReview(new ProductReview("Keyboard", "Nice and comfortable."));
        analytics.addReview(new ProductReview("Canteen", "Good capacity for long hikes."));
        analytics.addReview(new ProductReview("Canteen", "This is the best workout accessory."));
        analytics.addReview(new ProductReview("Canteen", "I run best with extra liquids."));
        analytics.addReview(new ProductReview("Canteen", "No leaks, best canteen yet."));
        
        int expected = 6;
        int actual = analytics.getNumGoodReviews("Canteen");
        assertEquals(expected, actual);
    }
    
    @Test
    public void getNumGoodReviewsTestTen()
    {
        analytics.addReview(new ProductReview("Monitor", "Looks great."));
        analytics.addReview(new ProductReview("Keyboard", "Nice key press action."));
        analytics.addReview(new ProductReview("Mouse", "Good response to motion."));
        analytics.addReview(new ProductReview("Keyboard", "The best keyboard out there."));
        analytics.addReview(new ProductReview("Keyboard", "Has the best key action."));
        analytics.addReview(new ProductReview("Keyboard", "Nice and comfortable typing."));
        analytics.addReview(new ProductReview("Laptop", "Good value for the money."));
        analytics.addReview(new ProductReview("Keyboard", "This is best for gaming."));
        analytics.addReview(new ProductReview("Keyboard", "Typists consider this the best."));
        analytics.addReview(new ProductReview("Keyboard", "The best contours and styling"));
        analytics.addReview(new ProductReview("Phone", "Sounds great, good battery life."));
        analytics.addReview(new ProductReview("Keyboard", "Has the best layout."));
        analytics.addReview(new ProductReview("Keyboard", "This is the best keyboard."));
        analytics.addReview(new ProductReview("Speaker", "Good bass and treble."));
        
        int expected = 7;
        int actual = analytics.getNumGoodReviews("Keyboard");
        assertEquals(expected, actual);
    }
}