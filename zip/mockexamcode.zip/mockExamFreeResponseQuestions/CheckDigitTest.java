/**
|-------------------------------------------------------------------------------
| CheckDigitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 9, 2020
|
| This program is the test bench for CheckDigit.java
|
| Do not alter the contents of this file.
|
*/

public class CheckDigitTest
{
    public static void main(String[] args)
    {
        int result = 0;
        result = CheckDigit.getCheck(283415);
        System.out.println("The check digit for 283415 should be 6: " + result);
        result = CheckDigit.getCheck(2183);
        System.out.println("The check digit for 2183 should be 2: " + result);
        result = CheckDigit.getCheck(159);
        System.out.println("The check digit for 159 should be 2: " + result);
        
        boolean outcome = false;
        outcome = CheckDigit.isValid(1592);
        System.out.println("Is 1592 a valid combination? Should be true: " + outcome);
        outcome = CheckDigit.isValid(1593);
        System.out.println("Is 1593 a valid combination? Should be false: " + outcome);
    }
}