/**
|-------------------------------------------------------------------------------
| ReviewCollectorTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 9, 2020
|
| This program is the test bench for ReviewCollector.java
|
| Do not alter the contents of this file.
|
*/

import java.util.*;

public class ReviewCollectorTest
{
    public static void main(String[] args)
    {
        System.out.println("Testing part (a): the addReview method.");
        ReviewCollector analytics = new ReviewCollector();
        analytics.addReview(new ProductReview("Laptop", "Works well."));
        analytics.addReview(new ProductReview("Phone", "Has the best sound."));
        analytics.addReview(new ProductReview("Bicycle", "Smooth ride."));
        analytics.addReview(new ProductReview("Phone", "The best handset around."));
        analytics.addReview(new ProductReview("Bicycle", "Good handling."));
        analytics.addReview(new ProductReview("Mouse", "The range is the best."));
        System.out.println("reviewList: " + analytics.getReviews());
        System.out.println("productList: " + analytics.getProducts());
        
        System.out.println();
        System.out.println("Testing part (b): the getNumGoodReviews method.");
        int result = 0;
        result = analytics.getNumGoodReviews("Phone");
        System.out.println("Quantity of good reviews for Phone? Should be 2: " + result);
    }
}