/**
|-------------------------------------------------------------------------------
| CheckDigitJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 14, 2020
|
| This is the JUnit test bench for CheckDigit.java
|
| Do not alter the contents of this file.
|
*/

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class CheckDigitJUnitTest
{   
    @Test
    public void getCheckTestOne()
    {
        int expected = 6;
        int actual = CheckDigit.getCheck(283415);
        assertEquals(expected, actual);
    }
    
    @Test
    public void getCheckTestTwo()
    {
        int expected = 2;
        int actual = CheckDigit.getCheck(2183);
        assertEquals(expected, actual);
    }
    
    @Test
    public void getCheckTestThree()
    {
        int expected = 2;
        int actual = CheckDigit.getCheck(159);
        assertEquals(expected, actual);
    }
    
    @Test
    public void getCheckTestFour()
    {
        int expected = 3;
        int actual = CheckDigit.getCheck(95);
        assertEquals(expected, actual);
    }
    
    @Test
    public void getCheckTestFive()
    {
        int expected = 9;
        int actual = CheckDigit.getCheck(13377);
        assertEquals(expected, actual);
    }
    
    @Test
    public void isValidTestSix()
    {
        boolean actual = CheckDigit.isValid(1592);
        assertTrue(actual);
    }
    
    @Test
    public void isValidTestSeven()
    {
        boolean actual = CheckDigit.isValid(253);
        assertFalse(actual);
    }
    
    @Test
    public void isValidTestEight()
    {
        boolean actual = CheckDigit.isValid(23866);
        assertTrue(actual);
    }
    
    @Test
    public void isValidTestNine()
    {
        boolean actual = CheckDigit.isValid(156543);
        assertFalse(actual);
    }
    
    @Test
    public void isValidTestTen()
    {
        boolean actual = CheckDigit.isValid(9283473);
        assertTrue(actual);
    }
}