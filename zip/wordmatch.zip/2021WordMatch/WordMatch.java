/**
|-------------------------------------------------------------------------------
| WordMatch.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 11, 2022
|
| This program implements a simple word matching game.
|
*/

public class WordMatch
{
    // instance variables
    private String secret;
    
    public WordMatch(String word)
    {
        secret = word;
    }
    
    public int scoreGuess(String guess)
    {
        // Part (a): YOUR CODE HERE
        
    }
    
    public String findBetterGuess(String guess1, String guess2)
    {
        // Part (b): YOUR CODE HERE
        
    }
}