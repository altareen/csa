/**
|-------------------------------------------------------------------------------
| WordMatchTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 11, 2022
|
| This is the test bench for WordMatch.java
| Do not alter the contents of this file.
|
*/

public class WordMatchTest
{
    public static void main(String[] args)
    {
        WordMatch game = new WordMatch("mississippi");
        System.out.println(game.scoreGuess("issipp"));
        
        WordMatch play = new WordMatch("concatenation");
        System.out.println(play.findBetterGuess("ten", "nation"));
    }
}