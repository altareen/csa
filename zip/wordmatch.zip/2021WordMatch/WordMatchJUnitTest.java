/**
|-------------------------------------------------------------------------------
| WordMatchJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 11, 2022
|
| This is the JUnit test bench for WordMatch.java
| Do not alter the contents of this file.
|
*/

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class WordMatchJUnitTest
{
    private WordMatch game;
    private WordMatch play;
    private WordMatch bout;
    
    @BeforeEach
    public void runBeforeEachTest()
    {
        game = new WordMatch("mississippi");
        play = new WordMatch("aaaabb");
        bout = new WordMatch("concatenation");
    }
    
    @AfterEach
    public void runAfterEachTest()
    {
        game = null;
        play = null;
        bout = null;
    }
    
    @Test
    public void scoreGuessTestOne()
    {
        int expected = 4;
        int actual = game.scoreGuess("i");
        assertEquals(expected, actual);
    }
    
    @Test
    public void scoreGuessTestTwo()
    {
        int expected = 18;
        int actual = game.scoreGuess("iss");
        assertEquals(expected, actual);
    }
    
    @Test
    public void scoreGuessTestThree()
    {
        int expected = 36;
        int actual = game.scoreGuess("issipp");
        assertEquals(expected, actual);
    }
    
    @Test
    public void scoreGuessTestFour()
    {
        int expected = 121;
        int actual = game.scoreGuess("mississippi");
        assertEquals(expected, actual);
    }
    
    @Test
    public void scoreGuessTestFive()
    {
        int expected = 4;
        int actual = play.scoreGuess("a");
        assertEquals(expected, actual);
    }
    
    @Test
    public void scoreGuessTestSix()
    {
        int expected = 12;
        int actual = play.scoreGuess("aa");
        assertEquals(expected, actual);
    }
    
    @Test
    public void scoreGuessTestSeven()
    {
        int expected = 18;
        int actual = play.scoreGuess("aaa");
        assertEquals(expected, actual);
    }
    
    @Test
    public void scoreGuessTestEight()
    {
        int expected = 16;
        int actual = play.scoreGuess("aabb");
        assertEquals(expected, actual);
    }
    
    @Test
    public void scoreGuessTestNine()
    {
        int expected = 0;
        int actual = game.scoreGuess("c");
        assertEquals(expected, actual);
    }
    
    @Test
    public void findBetterGuessTestTen()
    {
        String expected = "nation";
        String actual = bout.findBetterGuess("ten", "nation");
        assertEquals(expected, actual);
    }
    
    @Test
    public void findBetterGuessTestEleven()
    {
        String expected = "con";
        String actual = bout.findBetterGuess("con", "cat");
        assertEquals(expected, actual);
    }
}