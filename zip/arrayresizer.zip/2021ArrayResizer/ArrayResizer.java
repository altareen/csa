/**
|-------------------------------------------------------------------------------
| ArrayResizer.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 12, 2022
|
| This program manipulates a two-dimensional array of integers.
|
*/

public class ArrayResizer
{
    public static boolean isNonZeroRow(int[][] array2D, int r)
    {
        // Part (a): YOUR CODE HERE
        
    }
    
    public static int numNonZeroRows(int[][] array2D)
    {
        int count = 0;
        for (int row = 0; row < array2D.length; row++)
        {
            if (isNonZeroRow(array2D, row))
            {
                count++;
            }
        }
        return count;
    }
    
    public static int[][] resize(int[][] array2D)
    {
        // Part (b): YOUR CODE HERE
        
    }
}