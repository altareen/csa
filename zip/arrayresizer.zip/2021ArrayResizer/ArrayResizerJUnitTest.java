/**
|-------------------------------------------------------------------------------
| ArrayResizerJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 12, 2022
|
| This is the JUnit test bench for ArrayResizer.java
| Do not alter the contents of this file.
|
*/

import java.util.Arrays;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ArrayResizerJUnitTest
{
    private int[][] arr;
    
    @BeforeEach
    public void runBeforeEachTest()
    {
        arr = new int[][]{{2, 1, 0}, {1, 3, 2}, {0, 0, 0}, {4, 5, 6}};
    }
    
    @AfterEach
    public void runAfterEachTest()
    {
        arr = null;
    }
    
    @Test
    public void isNonZeroRowTestOne()
    {
        assertFalse(ArrayResizer.isNonZeroRow(arr, 0));
    }
    
    @Test
    public void isNonZeroRowTestTwo()
    {
        assertTrue(ArrayResizer.isNonZeroRow(arr, 1));
    }
    
    @Test
    public void isNonZeroRowTestThree()
    {
        assertFalse(ArrayResizer.isNonZeroRow(arr, 2));
    }
    
    @Test
    public void isNonZeroRowTestFour()
    {
        assertTrue(ArrayResizer.isNonZeroRow(arr, 3));
    }
    
    @Test
    public void resizeTestFive()
    {
        String expected = "[[1, 3, 2], [4, 5, 6]]";
        String actual = Arrays.deepToString(ArrayResizer.resize(arr));
        assertEquals(expected, actual);
    }
}