/**
|-------------------------------------------------------------------------------
| ArrayResizerTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 12, 2022
|
| This is the test bench for ArrayResizer.java
| Do not alter the contents of this file.
|
*/

import java.util.Arrays;

public class ArrayResizerTest
{
    public static void main(String[] args)
    {
        int[][] arr = {{2, 1, 0}, {1, 3, 2}, {0, 0, 0}, {4, 5, 6}};
        
        System.out.println(ArrayResizer.isNonZeroRow(arr, 0));
        System.out.println(ArrayResizer.isNonZeroRow(arr, 1));
        System.out.println(ArrayResizer.isNonZeroRow(arr, 2));
        System.out.println(ArrayResizer.isNonZeroRow(arr, 3));
        
        System.out.println(ArrayResizer.numNonZeroRows(arr));
        System.out.println(Arrays.deepToString(ArrayResizer.resize(arr)));
    }
}

