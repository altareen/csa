/**
|-------------------------------------------------------------------------------
| Trail.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Mar 26, 2020
|
| This program determines whether a trail is level or difficult.
|
*/

public class Trail
{
    private int[] markers;
    
    public Trail(int[] posts)
    {
        markers = posts;
    }
    
    public boolean isLevelTrailSegment(int start, int end)
    {
        // Part (a): YOUR CODE HERE
        
    }
    
    public boolean isDifficult()
    {
        // Part (b): YOUR CODE HERE
        
    }
}