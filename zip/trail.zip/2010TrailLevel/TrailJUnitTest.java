/**
|-------------------------------------------------------------------------------
| TrailJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Mar 26, 2020
|
| This program is the JUnit test bench for Trail.java
|
| Do not alter the contents of this file.
|
*/

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;

public class TrailJUnitTest
{
    private int[] altitudes;
    private Trail route;
    
    @Before
    public void runBeforeEachTest()
    {
        altitudes = new int[] {0, 0, 0, 0};
        route = new Trail(altitudes);
    }
    
    @After
    public void runAfterEachTest()
    {
        altitudes = null;
        route = null;
    }
    
    @Test
    public void testOne()
    {
        altitudes = new int[] {100,150,105,120,90,80,50,75,75,70,80,90,100};
        route = new Trail(altitudes);
        boolean actual = route.isLevelTrailSegment(7, 10);
        assertTrue(actual);
    }
    
    @Test
    public void testTwo()
    {
        altitudes = new int[] {100,150,105,120,90,80,50,75,75,70,80,90,100};
        route = new Trail(altitudes);
        boolean actual = route.isLevelTrailSegment(2, 12);
        assertFalse(actual);
    }
    
    @Test
    public void testThree()
    {
        altitudes = new int[] {100,150,105,120,90,80,50,75,75,70,80,90,100};
        route = new Trail(altitudes);
        boolean actual = route.isDifficult();
        assertTrue(actual);
    }
    
    @Test
    public void testFour()
    {
        altitudes = new int[] {146,135,135,143,88,53,114,96,75,129,58,112,142};
        route = new Trail(altitudes);
        boolean actual = route.isLevelTrailSegment(3, 8);
        assertFalse(actual);
    }
    
    @Test
    public void testFive()
    {
        altitudes = new int[] {146,135,135,143,88,53,114,96,75,129,58,112,142};
        route = new Trail(altitudes);
        boolean actual = route.isLevelTrailSegment(5, 10);
        assertFalse(actual);
    }
    
    @Test
    public void testSix()
    {
        altitudes = new int[] {100,150,105,120,90,80,50,75,75,70,80,90,100};
        route = new Trail(altitudes);
        boolean actual = route.isDifficult();
        assertTrue(actual);
    }
    
    @Test
    public void testSeven()
    {
        altitudes = new int[] {54,51,55,52,55,58,53,57,56,59,50,59,54};
        route = new Trail(altitudes);
        boolean actual = route.isLevelTrailSegment(1, 6);
        assertTrue(actual);
    }
    
    @Test
    public void testEight()
    {
        altitudes = new int[] {54,51,55,52,55,58,53,57,56,59,50,59,54};
        route = new Trail(altitudes);
        boolean actual = route.isLevelTrailSegment(3, 12);
        assertTrue(actual);
    }
    
    @Test
    public void testNine()
    {
        altitudes = new int[] {54,51,55,52,55,58,53,57,56,59,50,59,54};
        route = new Trail(altitudes);
        boolean actual = route.isDifficult();
        assertFalse(actual);
    }
    
    @Test
    public void testTen()
    {
        altitudes = new int[] {65,144,67,62,54,17,65,102,54,23,66,52,146,63,15,64};
        route = new Trail(altitudes);
        boolean actual = route.isDifficult();
        assertTrue(actual);
    }
}