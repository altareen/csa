/**
|-------------------------------------------------------------------------------
| Library.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Jan 16, 2020
|
| The Library class defines methods to represent each library, and manage a
| collection of books.
|
*/

import java.util.*;

public class Library
{
    private static String hours = "Libraries are open daily from 9am to 5pm.";
    private String address;
    private ArrayList<Book> bookInventory = new ArrayList<Book>();

    // 2 points    
    public Library(String libraryAddress)
    {
        // YOUR CODE HERE
        
    }
    
    // 2 points
    public static String displayOpeningHours()
    {
        // YOUR CODE HERE
        
    }
    
    // 2 points
    public String displayAddress()
    {
        // YOUR CODE HERE
        
    }
    
    // 2 points
    public String addBook(Book novel)
    {
        // YOUR CODE HERE
        
    }
    
    // 10 points
    public String borrowBook(String novelName)
    {
        // YOUR CODE HERE
        
    }

    // 5 points    
    public String displayAvailableBooks()
    {
        // YOUR CODE HERE
        
    }
    
    // 5 points
    public String returnBook(String textName)
    {
        // YOUR CODE HERE
        
    }
}
