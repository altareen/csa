/**
|-------------------------------------------------------------------------------
| StockBrokerJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Feb 03, 2020
|
| This program provides a testbench for the StockBroker class.
|
| Do not alter the contents of this file.
|
*/

import junit.framework.JUnit4TestAdapter;
import static org.junit.Assert.assertEquals;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class StockBrokerJUnitTest
{
    private StockBroker portfolio;
    
    @Before
    public void runBeforeEachTest()
    {
        portfolio = new StockBroker();
    }
    
    @After
    public void runAfterEachTest()
    {
        portfolio = null;
    }

    @Test
    public void getProfitTestOne()
    {
        portfolio.purchase(20, 3.50);
        portfolio.purchase(10, 2.00);
        double expected = 30.0;
        double actual = portfolio.getProfit(4.00);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void getProfitTestTwo()
    {
        portfolio.purchase(93, 2.48);
        portfolio.purchase(75, 9.23);
        double expected = -17.37;
        double actual = portfolio.getProfit(5.39);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void getProfitTestThree()
    {
        portfolio.purchase(38, 4.72);
        portfolio.purchase(43, 8.28);
        portfolio.purchase(64, 3.21);
        double expected = 670.01;
        double actual = portfolio.getProfit(9.73);
        assertEquals(expected, actual, 0.1);
    }
        
    @Test
    public void getProfitTestFour()
    {
        portfolio.purchase(87, 4.10);
        portfolio.purchase(24, 6.12);
        portfolio.purchase(39, 8.75);
        portfolio.purchase(62, 3.01);
        double expected = 825.67;
        double actual = portfolio.getProfit(8.76);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void getProfitTestFive()
    {
        portfolio.purchase(84, 7.52);
        portfolio.purchase(34, 9.87);
        portfolio.purchase(20, 3.98);
        portfolio.purchase(57, 4.37);
        portfolio.purchase(54, 3.87);
        double expected = 116.06;
        double actual = portfolio.getProfit(6.51);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void getProfitTestSix()
    {
        portfolio.purchase(68, 7.66);
        portfolio.purchase(37, 1.97);
        double expected = 122.33;
        double actual = portfolio.getProfit(6.82);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void getProfitTestSeven()
    {
        portfolio.purchase(92, 89.45);
        portfolio.purchase(28, 41.86);
        double expected = -1999.88;
        double actual = portfolio.getProfit(61.68);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void getProfitTestEight()
    {
        portfolio.purchase(261, 54.16);
        portfolio.purchase(341, 62.42);
        portfolio.purchase(879, 82.98);
        double expected = 81607.47;
        double actual = portfolio.getProfit(128.27);
        assertEquals(expected, actual, 0.1);
    }
        
    @Test
    public void getProfitTestNine()
    {
        portfolio.purchase(687, 87.12);
        portfolio.purchase(288, 44.36);
        portfolio.purchase(426, 40.65);
        portfolio.purchase(384, 65.41);
        double expected = 6514.89;
        double actual = portfolio.getProfit(68.11);
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void getProfitTestTen()
    {
        portfolio.purchase(982, 78.71);
        portfolio.purchase(387, 26.54);
        portfolio.purchase(872, 64.16);
        portfolio.purchase(264, 41.54);
        portfolio.purchase(451, 65.47);
        double expected = 196284.15;
        double actual = portfolio.getProfit(128.65);
        assertEquals(expected, actual, 0.1);
    }
}
