/**
|-------------------------------------------------------------------------------
| StockBrokerTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Feb 03, 2020
|
| This program provides a testbench for the StockBroker class.
|
| Do not alter the contents of this file.
|
*/

public class StockBrokerTest
{
    public static void main(String[] args)
    {
        StockBroker baidu = new StockBroker();
        baidu.purchase(20, 3.50);
        baidu.purchase(10, 2.00);
        double profit = baidu.getProfit(4.00);
        System.out.println("Profit earned = " + profit);
    }
}