/**
|-------------------------------------------------------------------------------
| StockBroker.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Feb 03, 2020
|
| This program manages the value of an investor's stock portfolio.
|
*/

import java.util.*;

public class StockBroker
{
    // YOUR CODE HERE
    
}