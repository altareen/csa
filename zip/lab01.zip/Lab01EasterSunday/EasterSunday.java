/**
|-------------------------------------------------------------------------------
| EasterSunday.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Sep 11, 2019
|
| This program determines the month and day of Easter.
|
*/

public class EasterSunday
{
    public static int[] retrieveDate(int year)
    {
        // determine the month and day that Easter occurs
        // YOUR CODE HERE
        
        
        int[] date = new int[2];
        date[0] = n;
        date[1] = p;
        return date;
    }
    
    public static void main(String[] args)
    {
        int[] result = retrieveDate(2001);
        System.out.println("Month: " + result[0] + " Day: " + result[1]);
    }
}
