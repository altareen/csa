/**
|-------------------------------------------------------------------------------
| EasterSundayJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Sep 11, 2019
|
| This program is the JUnit test bench for EasterSunday.java
|
*/

import static org.junit.Assert.assertArrayEquals;
import org.junit.Test;

public class EasterSundayJUnitTest
{
    @Test
    public void evaluateOne()
    {
        int[] expected = {4, 15};
        int[] actual = EasterSunday.retrieveDate(2001);
        assertArrayEquals(expected, actual);
    }
    
    @Test
    public void evaluateTwo()
    {
        int[] expected = {4, 4};
        int[] actual = EasterSunday.retrieveDate(2010);
        assertArrayEquals(expected, actual);
    }
    
    @Test
    public void evaluateThree()
    {
        int[] expected = {4, 9};
        int[] actual = EasterSunday.retrieveDate(1950);
        assertArrayEquals(expected, actual);
    }
    
    @Test
    public void evaluateFour()
    {
        int[] expected = {4, 7};
        int[] actual = EasterSunday.retrieveDate(1996);
        assertArrayEquals(expected, actual);
    }
    
    @Test
    public void evaluateFive()
    {
        int[] expected = {4, 20};
        int[] actual = EasterSunday.retrieveDate(1919);
        assertArrayEquals(expected, actual);
    }
    
    @Test
    public void evaluateSix()
    {
        int[] expected = {4, 3};
        int[] actual = EasterSunday.retrieveDate(1988);
        assertArrayEquals(expected, actual);
    }
    
    @Test
    public void evaluateSeven()
    {
        int[] expected = {4, 22};
        int[] actual = EasterSunday.retrieveDate(1973);
        assertArrayEquals(expected, actual);
    }
    
    @Test
    public void evaluateEight()
    {
        int[] expected = {4, 6};
        int[] actual = EasterSunday.retrieveDate(1958);
        assertArrayEquals(expected, actual);
    }
    
    @Test
    public void evaluateNine()
    {
        int[] expected = {4, 16};
        int[] actual = EasterSunday.retrieveDate(1911);
        assertArrayEquals(expected, actual);
    }
    
    @Test
    public void evaluateTen()
    {
        int[] expected = {3, 31};
        int[] actual = EasterSunday.retrieveDate(1907);
        assertArrayEquals(expected, actual);
    }
}
