/**
|-------------------------------------------------------------------------------
| ClubMembersTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 12, 2022
|
| This is the test bench for ClubMembers.java
| Do not alter the contents of this file.
|
*/

import java.util.ArrayList;

public class ClubMembersTest
{
    public static void main(String[] args)
    {
        String[] names = {"Adams, Alice", "Jones, Bob", "Moore, Carl", "Lewis, David", "Green, Edward"};
        ClubMembers students = new ClubMembers();
        students.addMembers(names, 2021);
        System.out.println(students.getMembers());
        
        ClubMembers roster = new ClubMembers();
        String[] jane = {"Smith, Jane"};
        roster.addMembers(jane, 2019);
        ArrayList<MemberInfo> pupils = roster.getMembers();
        pupils.get(pupils.size()-1).setGoodStanding(false);
        
        String[] steve = {"Fox, Steve"};
        roster.addMembers(steve, 2018);
        
        String[] michael = {"Xin, Michael"};
        roster.addMembers(michael, 2017);
        pupils = roster.getMembers();
        pupils.get(pupils.size()-1).setGoodStanding(false);
        
        String[] maria = {"Garcia, Maria"};
        roster.addMembers(maria, 2020);
        
        ArrayList<MemberInfo> graduated = roster.removeMembers(2018);
        System.out.println(roster.getMembers());
        System.out.println(graduated);
    }
}