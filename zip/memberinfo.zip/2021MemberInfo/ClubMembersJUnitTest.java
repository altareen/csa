/**
|-------------------------------------------------------------------------------
| ClubMembersJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 12, 2022
|
| This is the test bench for ClubMembers.java
| Do not alter the contents of this file.
|
*/

import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ClubMembersJUnitTest
{
    private ClubMembers students;
    private ClubMembers roster;
    private String[] names;
    private String[] jane;
    private String[] steve;
    private String[] michael;
    private String[] maria;
    
    @BeforeEach
    public void runBeforeEachTest()
    {
        students = new ClubMembers();
        roster = new ClubMembers();
        names = new String[]{"Adams, Alice", "Jones, Bob", "Moore, Carl", "Lewis, David", "Green, Edward"};
        jane = new String[]{"Smith, Jane"};
        steve = new String[]{"Fox, Steve"};
        michael = new String[]{"Xin, Michael"};
        maria = new String[]{"Garcia, Maria"};
    }
    
    @AfterEach
    public void runAfterEachTest()
    {
        students = null;
        roster = null;
        names = null;
        jane = null;
        steve = null;
        michael = null;
        maria = null;
    }
    
    @Test
    public void addMembersTestOne()
    {
        students.addMembers(names, 2021);
        String expected = "[(Adams, Alice/2021/true), (Jones, Bob/2021/true), (Moore, Carl/2021/true), (Lewis, David/2021/true), (Green, Edward/2021/true)]";
        String actual = students.getMembers().toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void removeMembersTestTwo()
    {
        roster.addMembers(jane, 2019);
        ArrayList<MemberInfo> pupils = roster.getMembers();
        pupils.get(pupils.size()-1).setGoodStanding(false);
        roster.addMembers(steve, 2018);
        roster.addMembers(michael, 2017);
        pupils = roster.getMembers();
        pupils.get(pupils.size()-1).setGoodStanding(false);
        roster.addMembers(maria, 2020);
        
        String expected = "[(Fox, Steve/2018/true)]";
        String actual = roster.removeMembers(2018).toString();
        assertEquals(expected, actual);
    }
}