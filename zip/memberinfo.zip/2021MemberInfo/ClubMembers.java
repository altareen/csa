/**
|-------------------------------------------------------------------------------
| ClubMembers.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 12, 2022
|
| This program maintains a list of current high school club members.
|
*/

import java.util.ArrayList;

public class ClubMembers
{
    // instance variables
    private ArrayList<MemberInfo> memberList;
    
    public ClubMembers()
    {
        memberList = new ArrayList<MemberInfo>();
    }
    
    public void addMembers(String[] names, int gradYear)
    {
        // Part (a): YOUR CODE HERE
        
    }
    
    public ArrayList<MemberInfo> removeMembers(int year)
    {
        // Part (b): YOUR CODE HERE
        
    }
    
    public ArrayList<MemberInfo> getMembers()
    {
        return memberList;
    }
}