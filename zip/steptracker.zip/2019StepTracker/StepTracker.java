/**
|-------------------------------------------------------------------------------
| StepTracker.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Dec 16, 2019
|
| This program implements a fitness tracking system.
|
*/

public class StepTracker
{
    // YOUR CODE HERE
    
}
