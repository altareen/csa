/**
|-------------------------------------------------------------------------------
| StepTrackerJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 11, 2020
|
| This is the JUnit test bench for StepTracker.java
|
| Do not alter the contents of this file.
|
*/

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import java.util.*;

public class StepTrackerJUnitTest
{
    private StepTracker tr;
    private StepTracker monitor;
    
    @Before
    public void runBeforeEachTest()
    {
        tr = new StepTracker(10000);
        monitor = new StepTracker(19841);
    }
    
    @After
    public void runAfterEachTest()
    {
        tr = null;
        monitor = null;
    }
    
    @Test
    public void activeDaysTestOne()
    {
        int expected = 0;
        int actual = tr.activeDays();
        assertEquals(expected, actual);
    }
        
    @Test
    public void activeDaysTestTwo()
    {
        tr.addDailySteps(9000);
        tr.addDailySteps(5000);
        int expected = 0;
        int actual = tr.activeDays();
        assertEquals(expected, actual);
    }
    
    @Test
    public void averageStepsTestThree()
    {
        tr.addDailySteps(9000);
        tr.addDailySteps(5000);
        double expected = 7000.0;
        double actual = tr.averageSteps();
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void activeDaysTestFour()
    {
        tr.addDailySteps(9000);
        tr.addDailySteps(5000);
        tr.addDailySteps(13000);
        int expected = 1;
        int actual = tr.activeDays();
        assertEquals(expected, actual);
    }
    
    @Test
    public void averageStepsTestFive()
    {
        tr.addDailySteps(9000);
        tr.addDailySteps(5000);
        tr.addDailySteps(13000);
        double expected = 9000.0;
        double actual = tr.averageSteps();
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void activeDaysTestSix()
    {
        tr.addDailySteps(9000);
        tr.addDailySteps(5000);
        tr.addDailySteps(13000);
        tr.addDailySteps(23000);
        tr.addDailySteps(1111);
        int expected = 2;
        int actual = tr.activeDays();
        assertEquals(expected, actual);
    }
    
    @Test
    public void averageStepsTestSeven()
    {
        tr.addDailySteps(9000);
        tr.addDailySteps(5000);
        tr.addDailySteps(13000);
        tr.addDailySteps(23000);
        tr.addDailySteps(1111);
        double expected = 10222.2;
        double actual = tr.averageSteps();
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void averageStepsTestEight()
    {
        monitor.addDailySteps(9283);
        monitor.addDailySteps(26234);
        double expected = 17758.5;
        double actual = monitor.averageSteps();
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void averageStepsTestNine()
    {
        monitor.addDailySteps(46513);
        monitor.addDailySteps(23841);
        monitor.addDailySteps(94811);
        monitor.addDailySteps(72362);
        double expected = 59381.75;
        double actual = monitor.averageSteps();
        assertEquals(expected, actual, 0.1);
    }
    
    @Test
    public void activeDaysTestTen()
    {
        monitor.addDailySteps(23873);
        monitor.addDailySteps(65132);
        monitor.addDailySteps(32512);
        monitor.addDailySteps(59831);
        monitor.addDailySteps(12658);
        monitor.addDailySteps(55684);
        monitor.addDailySteps(14964);
        monitor.addDailySteps(92857);
        int expected = 6;
        int actual = monitor.activeDays();
        assertEquals(expected, actual);
    }
}