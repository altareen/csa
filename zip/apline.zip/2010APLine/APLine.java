/**
|-------------------------------------------------------------------------------
| APLine.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Mar 26, 2020
|
| This program defines the equation of a straight line.
|
*/

public class APLine
{
    // YOUR CODE HERE
    
}