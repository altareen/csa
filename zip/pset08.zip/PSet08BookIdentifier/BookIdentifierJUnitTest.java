/**
|-------------------------------------------------------------------------------
| BookIdentifierJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Nov 03, 2019
|
| This is the JUnit test bench for BookIdentifier.java
| Do not alter the contents of this file.
|
*/

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class BookIdentifierJUnitTest
{
    @Test
    public void testOne()
    {
        String expected = "YES";
        String actual = BookIdentifier.validateBook("0789751984");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testTwo()
    {
        String expected = "YES";
        String actual = BookIdentifier.validateBook("0321776410");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testThree()
    {
        String expected = "YES";
        String actual = BookIdentifier.validateBook("0321842685");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testFour()
    {
        String expected = "YES";
        String actual = BookIdentifier.validateBook("0439708184");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testFive()
    {
        String expected = "YES";
        String actual = BookIdentifier.validateBook("0553593714");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSix()
    {
        String expected = "NO";
        String actual = BookIdentifier.validateBook("0789751985");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSeven()
    {
        String expected = "NO";
        String actual = BookIdentifier.validateBook("0558675309");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testEight()
    {
        String expected = "NO";
        String actual = BookIdentifier.validateBook("0178675309");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testNine()
    {
        String expected = "NO";
        String actual = BookIdentifier.validateBook("0128535937");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testTen()
    {
        String expected = "NO";
        String actual = BookIdentifier.validateBook("0168426065");
        assertEquals(expected, actual);
    }
}
