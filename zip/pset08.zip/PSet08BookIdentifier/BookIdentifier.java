/**
|-------------------------------------------------------------------------------
| BookIdentifier.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Nov 03, 2019
|
| This program checks the validity of ISBN codes.
|
*/

public class BookIdentifier
{
    public static String validateBook(String isbnCode)
    {
        // convert the isbnCode parameter to an integer called isbnNum
        int isbnNum = Integer.parseInt(isbnCode);
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        String result = validateBook("0789751984");
        System.out.println(result);
    }
}
