/**
|-------------------------------------------------------------------------------
| MixedSwap.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Apr 2, 2020
|
| This program scrambles a word according to a set of rules.
|
*/

import java.util.*;

public class MixedSwap
{
    public static String scrambleWord(String word)
    {
        // Part (a): YOUR CODE HERE
        
    }
        
    public static void scrambleOrRemove(List<String> wordList)
    {
        // Part (b): YOUR CODE HERE
        
    }
}
