/******************************************************************************
 *  Author:       Alwin Tareen
 *  Created:      Feb 18, 2019
 *  Last updated: Feb 18, 2019
 *
 *  Compilation:  javac HiddenWord.java
 *  Execution:    java HiddenWord
 *  
 *  This program implements a word guessing game.
 *
 ******************************************************************************/

public class HiddenWord
{
    private String word;
    
    public HiddenWord(String w)
    {
        word = w;
    }
    
    public String getHint(String hint)
    {
        // YOUR CODE HERE
        
    }
}
