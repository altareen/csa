/**
|-------------------------------------------------------------------------------
| CaesarCipher.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Nov 07, 2019
|
| This program encrypts a message using the caesar cipher.
|
*/

public class CaesarCipher
{
    public static String encrypt(String message, int key)
    {
        String alphabet = "abcdefghijklmnopqrstuvwxyz";
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        String result = encrypt("hello", 1);
        System.out.println(result);
    }
}
