/**
|-------------------------------------------------------------------------------
| QuarterbackRatingJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Sep 22, 2019
|
| This is the JUnit test bench for QuarterbackRating.java
| Do not alter the contents of this file.
|
*/

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class QuarterbackRatingJUnitTest
{
    @Test
    public void testCaseOne()
    {
        double expected = 99.107;
        double actual = QuarterbackRating.calculateRating(35, 26, 235, 2, 1);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseTwo()
    {
        double expected = 158.333;
        double actual = QuarterbackRating.calculateRating(33, 26, 465, 5, 0);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseThree()
    {
        double expected = 108.534;
        double actual = QuarterbackRating.calculateRating(62, 40, 464, 4, 0);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseFour()
    {
        double expected = 92.385;
        double actual = QuarterbackRating.calculateRating(58, 35, 437, 4, 2);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseFive()
    {
        double expected = 117.250;
        double actual = QuarterbackRating.calculateRating(50, 36, 422, 3, 0);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseSix()
    {
        double expected = 90.544;
        double actual = QuarterbackRating.calculateRating(26, 19, 172, 0, 0);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseSeven()
    {
        double expected = 74.019;
        double actual = QuarterbackRating.calculateRating(34, 17, 167, 1, 0);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseEight()
    {
        double expected = 36.300;
        double actual = QuarterbackRating.calculateRating(33, 16, 151, 0, 2);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseNine()
    {
        double expected = 73.958;
        double actual = QuarterbackRating.calculateRating(20, 16, 145, 1, 2);
        assertEquals(expected, actual, 2);
    }
    
    @Test
    public void testCaseTen()
    {
        double expected = 49.768;
        double actual = QuarterbackRating.calculateRating(18, 9, 126, 0, 1);
        assertEquals(expected, actual, 2);
    }
}