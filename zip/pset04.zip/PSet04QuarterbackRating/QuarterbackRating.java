/**
|-------------------------------------------------------------------------------
| QuarterbackRating.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Sep 22, 2019
|
| This program determines the passer rating of an NFL quarterback.
|
*/

public class QuarterbackRating
{
    public static double calculateRating(int attempts, int comps, int yards, int tdowns, int picks)
    {
        double rating = 0.0;
        // YOUR CODE HERE
        
        return rating;
    }
    
    public static void main(String[] args)
    {
        double result = calculateRating(35, 26, 235, 2, 1);
        System.out.println(result);
    }
}