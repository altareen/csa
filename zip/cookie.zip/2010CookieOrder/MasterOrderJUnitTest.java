/**
|-------------------------------------------------------------------------------
| MasterOrderJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Mar 25, 2020
|
| This program is the JUnit test bench for MasterOrder.java
|
| Do not alter the contents of this file.
|
*/

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import java.util.*;

public class MasterOrderJUnitTest
{
    private MasterOrder goodies;
    
    @Before
    public void runBeforeEachTest()
    {
        goodies = new MasterOrder();
    }
    
    @After
    public void runAfterEachTest()
    {
        goodies = null;
    }
    
    @Test
    public void testOne()
    {
        goodies.addOrder(new CookieOrder("Chocolate Chip", 1));
        goodies.addOrder(new CookieOrder("Shortbread", 5));
        goodies.addOrder(new CookieOrder("Macaroon", 2));
        goodies.addOrder(new CookieOrder("Chocolate Chip", 3));
        int expected = 11;
        int actual = goodies.getTotalBoxes();
        assertEquals(expected, actual);
    }
    
    @Test
    public void testTwo()
    {
        goodies.addOrder(new CookieOrder("Chocolate Chip", 1));
        goodies.addOrder(new CookieOrder("Shortbread", 5));
        goodies.addOrder(new CookieOrder("Macaroon", 2));
        goodies.addOrder(new CookieOrder("Chocolate Chip", 3));
        int expected = 4;
        int actual = goodies.removeVariety("Chocolate Chip");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testThree()
    {
        goodies.addOrder(new CookieOrder("Chocolate Chip", 1));
        goodies.addOrder(new CookieOrder("Shortbread", 5));
        goodies.addOrder(new CookieOrder("Macaroon", 2));
        goodies.addOrder(new CookieOrder("Chocolate Chip", 3));
        goodies.removeVariety("Chocolate Chip");
        
        ArrayList<CookieOrder> snacks = new ArrayList<CookieOrder>();
        snacks.add(new CookieOrder("Shortbread", 5));
        snacks.add(new CookieOrder("Macaroon", 2));
        
        String expected = snacks.toString();
        String actual = goodies.getOrders().toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void testFour()
    {
        goodies.addOrder(new CookieOrder("Cinnamon", 12));
        goodies.addOrder(new CookieOrder("Mint Thins", 7));
        goodies.addOrder(new CookieOrder("Oatmeal", 15));
        goodies.addOrder(new CookieOrder("Almond Crunch", 18));
        goodies.addOrder(new CookieOrder("Cinnamon", 16));
        goodies.addOrder(new CookieOrder("Chunky Chocolate", 11));
        goodies.addOrder(new CookieOrder("Cinnamon", 23));
        int expected = 102;
        int actual = goodies.getTotalBoxes();
        assertEquals(expected, actual);
    }
    
    @Test
    public void testFive()
    {
        goodies.addOrder(new CookieOrder("Cinnamon", 12));
        goodies.addOrder(new CookieOrder("Mint Thins", 7));
        goodies.addOrder(new CookieOrder("Oatmeal", 15));
        goodies.addOrder(new CookieOrder("Almond Crunch", 18));
        goodies.addOrder(new CookieOrder("Cinnamon", 16));
        goodies.addOrder(new CookieOrder("Chunky Chocolate", 11));
        goodies.addOrder(new CookieOrder("Cinnamon", 23));
        int expected = 51;
        int actual = goodies.removeVariety("Cinnamon");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSix()
    {
        goodies.addOrder(new CookieOrder("Cinnamon", 12));
        goodies.addOrder(new CookieOrder("Mint Thins", 7));
        goodies.addOrder(new CookieOrder("Oatmeal", 15));
        goodies.addOrder(new CookieOrder("Almond Crunch", 18));
        goodies.addOrder(new CookieOrder("Cinnamon", 16));
        goodies.addOrder(new CookieOrder("Chunky Chocolate", 11));
        goodies.addOrder(new CookieOrder("Cinnamon", 23));
        goodies.removeVariety("Cinnamon");
        
        ArrayList<CookieOrder> snacks = new ArrayList<CookieOrder>();
        snacks.add(new CookieOrder("Mint Thins", 7));
        snacks.add(new CookieOrder("Oatmeal", 15));
        snacks.add(new CookieOrder("Almond Crunch", 18));
        snacks.add(new CookieOrder("Chunky Chocolate", 11));
        
        String expected = snacks.toString();
        String actual = goodies.getOrders().toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSeven()
    {
        goodies.addOrder(new CookieOrder("Chocolate Chip", 32));
        goodies.addOrder(new CookieOrder("Pecan Medley", 93));
        goodies.addOrder(new CookieOrder("Oatmeal", 38));
        goodies.addOrder(new CookieOrder("Raisin", 51));
        goodies.addOrder(new CookieOrder("Cinnamon", 64));
        goodies.addOrder(new CookieOrder("Almond Crunch", 54));
        goodies.addOrder(new CookieOrder("Chocolate Chip", 71));
        goodies.addOrder(new CookieOrder("Mint Thins", 58));
        goodies.addOrder(new CookieOrder("Cinnamon", 102));
        goodies.addOrder(new CookieOrder("Chunky Chocolate", 52));
        goodies.addOrder(new CookieOrder("Raisin", 98));
        goodies.addOrder(new CookieOrder("Oatmeal", 49));
        goodies.addOrder(new CookieOrder("Pecan Medley", 18));
        goodies.addOrder(new CookieOrder("Chunky Chocolate", 24));
        goodies.addOrder(new CookieOrder("Chocolate Chip", 116));
        goodies.addOrder(new CookieOrder("Oatmeal", 235));
        goodies.addOrder(new CookieOrder("Mint Thins", 17));
        goodies.addOrder(new CookieOrder("Pecan Medley", 61));
        goodies.addOrder(new CookieOrder("Almond Crunch", 128));
        goodies.addOrder(new CookieOrder("Cinnamon", 23));
        int expected = 1384;
        int actual = goodies.getTotalBoxes();
        assertEquals(expected, actual);
    }
    
    @Test
    public void testEight()
    {
        goodies.addOrder(new CookieOrder("Chocolate Chip", 32));
        goodies.addOrder(new CookieOrder("Pecan Medley", 93));
        goodies.addOrder(new CookieOrder("Oatmeal", 38));
        goodies.addOrder(new CookieOrder("Raisin", 51));
        goodies.addOrder(new CookieOrder("Cinnamon", 64));
        goodies.addOrder(new CookieOrder("Almond Crunch", 54));
        goodies.addOrder(new CookieOrder("Chocolate Chip", 71));
        goodies.addOrder(new CookieOrder("Mint Thins", 58));
        goodies.addOrder(new CookieOrder("Cinnamon", 102));
        goodies.addOrder(new CookieOrder("Chunky Chocolate", 52));
        goodies.addOrder(new CookieOrder("Raisin", 98));
        goodies.addOrder(new CookieOrder("Oatmeal", 49));
        goodies.addOrder(new CookieOrder("Pecan Medley", 18));
        goodies.addOrder(new CookieOrder("Chunky Chocolate", 24));
        goodies.addOrder(new CookieOrder("Chocolate Chip", 116));
        goodies.addOrder(new CookieOrder("Oatmeal", 235));
        goodies.addOrder(new CookieOrder("Mint Thins", 17));
        goodies.addOrder(new CookieOrder("Pecan Medley", 61));
        goodies.addOrder(new CookieOrder("Almond Crunch", 128));
        goodies.addOrder(new CookieOrder("Cinnamon", 23));
        int expected = 219;
        int actual = goodies.removeVariety("Chocolate Chip");
        assertEquals(expected, actual);
    }
    
    @Test
    public void testNine()
    {
        goodies.addOrder(new CookieOrder("Chocolate Chip", 32));
        goodies.addOrder(new CookieOrder("Pecan Medley", 93));
        goodies.addOrder(new CookieOrder("Oatmeal", 38));
        goodies.addOrder(new CookieOrder("Raisin", 51));
        goodies.addOrder(new CookieOrder("Cinnamon", 64));
        goodies.addOrder(new CookieOrder("Almond Crunch", 54));
        goodies.addOrder(new CookieOrder("Chocolate Chip", 71));
        goodies.addOrder(new CookieOrder("Mint Thins", 58));
        goodies.addOrder(new CookieOrder("Cinnamon", 102));
        goodies.addOrder(new CookieOrder("Chunky Chocolate", 52));
        goodies.addOrder(new CookieOrder("Raisin", 98));
        goodies.addOrder(new CookieOrder("Oatmeal", 49));
        goodies.addOrder(new CookieOrder("Pecan Medley", 18));
        goodies.addOrder(new CookieOrder("Chunky Chocolate", 24));
        goodies.addOrder(new CookieOrder("Chocolate Chip", 116));
        goodies.addOrder(new CookieOrder("Oatmeal", 235));
        goodies.addOrder(new CookieOrder("Mint Thins", 17));
        goodies.addOrder(new CookieOrder("Pecan Medley", 61));
        goodies.addOrder(new CookieOrder("Almond Crunch", 128));
        goodies.addOrder(new CookieOrder("Cinnamon", 23));
        goodies.removeVariety("Oatmeal");
        goodies.removeVariety("Pecan Medley");
        
        ArrayList<CookieOrder> snacks = new ArrayList<CookieOrder>();
        snacks.add(new CookieOrder("Chocolate Chip", 32));
        snacks.add(new CookieOrder("Raisin", 51));
        snacks.add(new CookieOrder("Cinnamon", 64));
        snacks.add(new CookieOrder("Almond Crunch", 54));
        snacks.add(new CookieOrder("Chocolate Chip", 71));
        snacks.add(new CookieOrder("Mint Thins", 58));
        snacks.add(new CookieOrder("Cinnamon", 102));
        snacks.add(new CookieOrder("Chunky Chocolate", 52));
        snacks.add(new CookieOrder("Raisin", 98));
        snacks.add(new CookieOrder("Chunky Chocolate", 24));
        snacks.add(new CookieOrder("Chocolate Chip", 116));
        snacks.add(new CookieOrder("Mint Thins", 17));
        snacks.add(new CookieOrder("Almond Crunch", 128));
        snacks.add(new CookieOrder("Cinnamon", 23));
        
        String expected = snacks.toString();
        String actual = goodies.getOrders().toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void testTen()
    {
        goodies.addOrder(new CookieOrder("Chocolate Chip", 32));
        goodies.addOrder(new CookieOrder("Pecan Medley", 93));
        goodies.addOrder(new CookieOrder("Oatmeal", 38));
        goodies.addOrder(new CookieOrder("Raisin", 51));
        goodies.addOrder(new CookieOrder("Cinnamon", 64));
        goodies.addOrder(new CookieOrder("Almond Crunch", 54));
        goodies.addOrder(new CookieOrder("Chocolate Chip", 71));
        goodies.addOrder(new CookieOrder("Mint Thins", 58));
        goodies.addOrder(new CookieOrder("Cinnamon", 102));
        goodies.addOrder(new CookieOrder("Chunky Chocolate", 52));
        goodies.addOrder(new CookieOrder("Raisin", 98));
        goodies.addOrder(new CookieOrder("Oatmeal", 49));
        goodies.addOrder(new CookieOrder("Pecan Medley", 18));
        goodies.addOrder(new CookieOrder("Chunky Chocolate", 24));
        goodies.addOrder(new CookieOrder("Chocolate Chip", 116));
        goodies.addOrder(new CookieOrder("Oatmeal", 235));
        goodies.addOrder(new CookieOrder("Mint Thins", 17));
        goodies.addOrder(new CookieOrder("Pecan Medley", 61));
        goodies.addOrder(new CookieOrder("Almond Crunch", 128));
        goodies.addOrder(new CookieOrder("Cinnamon", 23));
        goodies.removeVariety("Oatmeal");
        goodies.removeVariety("Pecan Medley");
        goodies.removeVariety("Chocolate Chip");
        goodies.removeVariety("Raisin");
        
        ArrayList<CookieOrder> snacks = new ArrayList<CookieOrder>();
        snacks.add(new CookieOrder("Cinnamon", 64));
        snacks.add(new CookieOrder("Almond Crunch", 54));
        snacks.add(new CookieOrder("Mint Thins", 58));
        snacks.add(new CookieOrder("Cinnamon", 102));
        snacks.add(new CookieOrder("Chunky Chocolate", 52));
        snacks.add(new CookieOrder("Chunky Chocolate", 24));
        snacks.add(new CookieOrder("Mint Thins", 17));
        snacks.add(new CookieOrder("Almond Crunch", 128));
        snacks.add(new CookieOrder("Cinnamon", 23));
        
        String expected = snacks.toString();
        String actual = goodies.getOrders().toString();
        assertEquals(expected, actual);
    }
}