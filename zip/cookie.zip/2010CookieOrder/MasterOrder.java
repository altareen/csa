/**
|-------------------------------------------------------------------------------
| MasterOrder.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Mar 25, 2020
|
| This program maintains a list of the cookies to be purchased.
|
*/

import java.util.*;

public class MasterOrder
{
    private ArrayList<CookieOrder> orders;
    
    public MasterOrder()
    {
        orders = new ArrayList<CookieOrder>();
    }
    
    public void addOrder(CookieOrder theOrder)
    {
        orders.add(theOrder);
    }
    
    public int getTotalBoxes()
    {
        // Part (a): YOUR CODE HERE
        
    }
    
    public int removeVariety(String cookieVar)
    {
        // Part (b): YOUR CODE HERE
        
    }
    
    public ArrayList<CookieOrder> getOrders()
    {
        return orders;
    }
}