/**
|-------------------------------------------------------------------------------
| CookieOrder.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Mar 25, 2020
|
| This program specifies the variety of cookie and the number of boxes ordered.
|
*/

public class CookieOrder
{
    private String variety;
    private int numBoxes;
    
    public CookieOrder(String var, int num)
    {
        variety = var;
        numBoxes = num;
    }
    
    public String getVariety()
    {
        return variety;
    }
    
    public int getNumBoxes()
    {
        return numBoxes;
    }
    
    public String toString()
    {
        return variety + ": " + numBoxes;
    }
}