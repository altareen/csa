/**
|-------------------------------------------------------------------------------
| RadiationExposure.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Nov 10, 2019
|
| This program determines the amount of radiation exposure in a given time frame.
|
*/

public class RadiationExposure
{
    // this function describes the radioactive decay curve of Cobalt-60
    public static double f(double x)
    {
        double activity = 10*Math.exp(Math.log(0.5)/5.27 * x);
        return activity;
    }
    
    public static double decayCurveArea(int start, int stop, double step)
    {
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        double result = decayCurveArea(5, 11, 1);
        System.out.println(result);
    }
}
