/**
|-------------------------------------------------------------------------------
| MusicDownloadsJUnitTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Mar 31, 2020
|
| This program is the JUnit test bench for MusicDownloads.java
|
| Do not alter the contents of this file.
|
*/

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.util.*;

public class MusicDownloadsJUnitTest
{
    private MusicDownloads webMusicA;
    private MusicDownloads webMusicB;
    private DownloadInfo jude;
    private DownloadInfo soul;
    private DownloadInfo aqua;
    private ArrayList<String> songTitles;
    private DownloadInfo fun;
    private DownloadInfo mack;
    private DownloadInfo lorde;
    private DownloadInfo taylor;
    private DownloadInfo mars;
    private ArrayList<String> popMusic;
    
    @Before
    public void runBeforeEachTest()
    {
        webMusicA = new MusicDownloads();
        webMusicB = new MusicDownloads();
        
        jude = new DownloadInfo("Hey Jude");
        jude.setTimesDownloaded(5);
        soul = new DownloadInfo("Soul Sister");
        soul.setTimesDownloaded(3);
        aqua = new DownloadInfo("Aqualung");
        aqua.setTimesDownloaded(10);
        
        webMusicA.addDownloadInfo(jude);
        webMusicA.addDownloadInfo(soul);
        webMusicA.addDownloadInfo(aqua);
           
        songTitles = new ArrayList<String>();
        songTitles.add("Lights");
        songTitles.add("Aqualung");
        songTitles.add("Soul Sister");
        songTitles.add("Go Now");
        songTitles.add("Lights");
        songTitles.add("Soul Sister");
        
        fun = new DownloadInfo("We Are Young");
        fun.setTimesDownloaded(23);
        mack = new DownloadInfo("Thrift Shop");
        mack.setTimesDownloaded(18);
        lorde = new DownloadInfo("Royals");
        lorde.setTimesDownloaded(35);
        taylor = new DownloadInfo("Shake It Off");
        taylor.setTimesDownloaded(92);
        mars = new DownloadInfo("Uptown Funk");
        mars.setTimesDownloaded(81);
        
        webMusicB.addDownloadInfo(fun);
        webMusicB.addDownloadInfo(mack);
        webMusicB.addDownloadInfo(lorde);
        webMusicB.addDownloadInfo(taylor);
        webMusicB.addDownloadInfo(mars);
        
        popMusic = new ArrayList<String>();
        popMusic.add("Shake It Off");
        popMusic.add("Thrift Shop");
        popMusic.add("Despacito");
        popMusic.add("Royals");
        popMusic.add("Havana");
        popMusic.add("Shake It Off");
        popMusic.add("Shake It Off");
        popMusic.add("Bad Guy");
        popMusic.add("Thrift Shop");
    }
    
    @After
    public void runAfterEachTest()
    {
        webMusicA = null;
        webMusicB = null;
        jude = null;
        soul = null;
        aqua = null;
        songTitles = null;
        fun = null;
        mack = null;
        lorde = null;
        taylor = null;
        mars = null;
        popMusic = null;
    }
    
    @Test
    public void testOne()
    {
        String expected = "(Hey Jude:5)";
        String actual = webMusicA.getDownloadInfo("Hey Jude").toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void testTwo()
    {
        String expected = "(Soul Sister:3)";
        String actual = webMusicA.getDownloadInfo("Soul Sister").toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void testThree()
    {
        String expected = "(Aqualung:10)";
        String actual = webMusicA.getDownloadInfo("Aqualung").toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void testFour()
    {
        assertNull(webMusicA.getDownloadInfo("Happy Birthday"));
    }
    
    @Test
    public void testFive()
    {
        webMusicA.updateDownloads(songTitles);
        String expected = "[(Hey Jude:5), (Soul Sister:5), (Aqualung:11), (Lights:2), (Go Now:1)]";
        String actual = webMusicA.getDownloadList().toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSix()
    {
        String expected = "(We Are Young:23)";
        String actual = webMusicB.getDownloadInfo("We Are Young").toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void testSeven()
    {
        String expected = "(Thrift Shop:18)";
        String actual = webMusicB.getDownloadInfo("Thrift Shop").toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void testEight()
    {
        String expected = "(Royals:35)";
        String actual = webMusicB.getDownloadInfo("Royals").toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void testNine()
    {
        String expected = "(Shake It Off:92)";
        String actual = webMusicB.getDownloadInfo("Shake It Off").toString();
        assertEquals(expected, actual);
    }
    
    @Test
    public void testTen()
    {
        webMusicB.updateDownloads(popMusic);
        String expected = "[(We Are Young:23), (Thrift Shop:20), (Royals:36), (Shake It Off:95), (Uptown Funk:81), (Despacito:1), (Havana:1), (Bad Guy:1)]";
        String actual = webMusicB.getDownloadList().toString();
        assertEquals(expected, actual);
    }
}