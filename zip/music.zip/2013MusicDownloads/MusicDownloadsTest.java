/**
|-------------------------------------------------------------------------------
| MusicDownloadsTest.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Mar 31, 2020
|
| This program is the test bench for MusicDownloads.java
|
| Do not alter the contents of this file.
|
*/

import java.util.*;

public class MusicDownloadsTest
{
    public static void main(String[] args)
    {
        // Question (a)
        DownloadInfo jude = new DownloadInfo("Hey Jude");
        jude.setTimesDownloaded(5);
        DownloadInfo soul = new DownloadInfo("Soul Sister");
        soul.setTimesDownloaded(3);
        DownloadInfo aqua = new DownloadInfo("Aqualung");
        aqua.setTimesDownloaded(10);
        
        MusicDownloads webMusicA = new MusicDownloads();
        webMusicA.addDownloadInfo(jude);
        webMusicA.addDownloadInfo(soul);
        webMusicA.addDownloadInfo(aqua);

        System.out.println(webMusicA.getDownloadInfo("Aqualung"));
        System.out.println(webMusicA.getDownloadInfo("Happy Birthday"));

        // Question (b)
        ArrayList<String> songTitles = new ArrayList<String>();
        songTitles.add("Lights");
        songTitles.add("Aqualung");
        songTitles.add("Soul Sister");
        songTitles.add("Go Now");
        songTitles.add("Lights");
        songTitles.add("Soul Sister");
        
        MusicDownloads webMusicB = new MusicDownloads();
        webMusicB.addDownloadInfo(jude);
        webMusicB.addDownloadInfo(soul);
        webMusicB.addDownloadInfo(aqua);

        System.out.println();
        System.out.println("Before:");
        System.out.println(webMusicB.getDownloadList());
        
        webMusicB.updateDownloads(songTitles);
        System.out.println("After:");
        System.out.println(webMusicB.getDownloadList());
    }
}