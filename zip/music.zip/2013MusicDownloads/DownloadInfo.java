/**
|-------------------------------------------------------------------------------
| DownloadInfo.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Mar 31, 2020
|
| This program keeps track of downloaded music.
|
*/

public class DownloadInfo
{
    private String songTitle;
    private int numTimesDownloaded;
    
    public DownloadInfo(String title)
    {
        songTitle = title;
        numTimesDownloaded = 1;
    }
    
    public String getTitle()
    {
        return songTitle;
    }
    
    public int getDownloads()
    {
        return numTimesDownloaded;
    }

    public void incrementTimesDownloaded()
    {
        numTimesDownloaded += 1;
    }
    
    public void setTimesDownloaded(int timesDownloaded)
    {
        numTimesDownloaded = timesDownloaded;
    }
    
    public String toString()
    {
        return "(" + songTitle + ":" + numTimesDownloaded + ")";
    }
}