/**
|-------------------------------------------------------------------------------
| MusicDownloads.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Mar 31, 2020
|
| This program stores an ArrayList of songs.
|
*/

import java.util.*;

public class MusicDownloads
{
    private ArrayList<DownloadInfo> downloadList;
    
    public MusicDownloads()
    {
        downloadList = new ArrayList<DownloadInfo>();
    }
    
    public void addDownloadInfo(DownloadInfo item)
    {
        downloadList.add(item);
    }
    
    public ArrayList<DownloadInfo> getDownloadList()
    {
        return downloadList;
    }
    
    public DownloadInfo getDownloadInfo(String title)
    {
        // Part (a): YOUR CODE HERE
        
    }
    
    public void updateDownloads(ArrayList<String> titles)
    {
        // Part (b): YOUR CODE HERE
        
    }
}