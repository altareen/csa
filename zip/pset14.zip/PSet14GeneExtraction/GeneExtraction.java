/**
|-------------------------------------------------------------------------------
| GeneExtraction.java
|-------------------------------------------------------------------------------
|
| Author:  Alwin Tareen
| Created: Feb 04, 2020
|
| This program determines whether a gene is present in a DNA sequence.
|
*/

public class GeneExtraction
{
    public static String geneSequence(String dna)
    {
        // YOUR CODE HERE
        
    }
    
    public static void main(String[] args)
    {
        String result = geneSequence("GTCATGCTACGTACGTATCGAGTCTCGTAACTG");
        System.out.println(result);
    }
}